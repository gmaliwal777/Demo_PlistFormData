//
//  WSConnection.m
//  BewaakDeBuurt
//
//  Created by Ghanshyam on 06/05/14.
//
//

#import "WSConnection.h"
#import <UIKit/UIKit.h>

@implementation WSConnection

-(void)postDataWithSession:(NSString *)strWebURL{
    //Creating NSURL Object
    NSURL *url = [NSURL URLWithString:strWebURL];
    
    //Creating Configurable
    NSURLSessionConfiguration *configSession = [NSURLSessionConfiguration defaultSessionConfiguration];
    NSURLSession *session = [NSURLSession sessionWithConfiguration:configSession];
    
    //Mutable Request
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:url];
    request.HTTPMethod = @"POST";
    
    //Creating JSON Dictionary
    NSDictionary *dictParams = [[NSDictionary alloc] initWithObjectsAndKeys:@"gm@gmail.com" ,@"username",@"123456",@"password", nil];
    NSError *error = nil;
    NSData *postData = [NSJSONSerialization dataWithJSONObject:dictParams options:kNilOptions error:&error];
    
    if (!error) {
        NSURLSessionUploadTask *uploadTask = [session uploadTaskWithRequest:request fromData:postData completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
            NSError *jsonError;
            NSString *strData = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&jsonError];
            if (!jsonError) {
                //NSLog(@"string data is %@",strData);
            }
        }];
        [uploadTask resume];
    }
}


-(void)getImageWithSession:(NSString *)imgURL{
    //1
    NSURL *url = [NSURL URLWithString:imgURL];
    
    //NSURLRequest *request = [NSURLRequest requestWithURL:url cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:2];
    
    
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    //2
    NSURLSessionDownloadTask *downLoadTask = [[NSURLSession sharedSession] downloadTaskWithRequest:request completionHandler:^(NSURL *location, NSURLResponse *response, NSError *error) {
        UIImage *downLoadedImage = [UIImage imageWithData:[NSData dataWithContentsOfURL:location]];
        //NSLog(@"image width is %f",downLoadedImage.size.width);
    }];
    
    //3
    [downLoadTask resume];
}


-(void)sendGetRequestWithUrl:(NSString *)strWebURL backgroundQueue:(dispatch_queue_t)queue{
    //self.backgroundQueue = queue;
    //dispatch_async(_backgroundQueue, ^{
        //Here we are holding reference of secondary queue
        //self.backgroundQueue = queue;
        
        //This is URL to webservice
        NSURL *webURL = [NSURL URLWithString:strWebURL];
        
        
        //We create request
        //NSURLRequest *request = [NSURLRequest requestWithURL:webURL cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:2];
        NSURLRequest *request = [NSURLRequest requestWithURL:webURL];
        
        //Initially allocating NSMutableData object to collect data
        self.wsData = [[NSMutableData alloc] init];
        
        //Creating Connection for Webservice
        _connection = [[NSURLConnection alloc] initWithRequest:request delegate:self startImmediately:YES];
        [_connection scheduleInRunLoop:[NSRunLoop currentRunLoop] forMode:NSRunLoopCommonModes];
        
        
        //Starting Runloop
        //[[NSRunLoop currentRunLoop] run];
        
        if (_connection == nil) {
            self.connection = nil;
            self.wsData = nil;
        }
   // });
}




-(void)cancelDownLoading{
    [self.connection cancel];
    self.connection = nil;
    self.wsData = nil;
}

-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{
    NSLog(@"Connection failed occurred");
    //dispatch_sync(dispatch_get_main_queue(), ^{
        if (self.completionHandler) {
            self.completionHandler(self.wsData,(int)_headerResponse.statusCode);
        }
        self.connection = nil;
        self.wsData = nil;
   // });
}

-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data{
    NSLog(@"Connection data received ");
    ////NSLog(@"data received is %@",data);
    [_wsData appendData:data];
    ////NSLog(@"data after is %@",_wsData);
    
}

-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response{
    NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse*)response;
    self.headerResponse = httpResponse ;
}

-(void)connectionDidFinishLoading:(NSURLConnection *)connection{
    NSLog(@"did finish loading");
    //dispatch_sync(dispatch_get_main_queue(), ^{
        if (self.completionHandler) {
            self.completionHandler(self.wsData,(int)_headerResponse.statusCode );
        }
        self.connection = nil;
        self.wsData = nil;
   // });
}

-(void)dealloc{
    NSLog(@"WSconnection dealloc");
    self.connection         = nil;
    self.wsData             = nil;
    self.completionHandler  = nil;
    self.postData           = nil;
    self.headerResponse     = nil;
}

@end
