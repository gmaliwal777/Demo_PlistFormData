//
//  WSConnection.h
//  BewaakDeBuurt
//
//  Created by Ghanshyam on 06/05/14.
//
//

#import <Foundation/Foundation.h>

@interface WSConnection : NSObject

@property (strong,nonatomic)    NSMutableData       *wsData;
@property (strong,nonatomic)    NSURLConnection     *connection;
@property (nonatomic,strong)    NSData              *postData;
@property (strong,nonatomic)    dispatch_queue_t    backgroundQueue;
@property (strong,nonatomic)    NSHTTPURLResponse   *headerResponse;

@property (nonatomic,strong)    void (^completionHandler)(NSData *responseData,int statusCode);


-(void)sendGetRequestWithUrl:(NSString *)strWebURL backgroundQueue:(dispatch_queue_t)queue;
-(void)postDataWithSession:(NSString *)strWebURL;
-(void)getImageWithSession:(NSString *)imgURL;

@end
