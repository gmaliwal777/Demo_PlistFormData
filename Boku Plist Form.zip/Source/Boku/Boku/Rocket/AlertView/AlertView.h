//
//  AlertView.h
//  eCitizens
//
//  Created by Ghanshyam on 3/9/15.
//  Copyright (c) 2015 Suchita. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


@interface AlertView : NSObject<UIAlertViewDelegate>{
    NSMutableArray     *arrTabs;
}

-(void)showAlertView:(NSString *)message arrActions:(NSArray *)arrActions;

@end
