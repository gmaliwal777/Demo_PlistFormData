//
//  DatePickerView.h
//  Boku
//
//  Created by Ghanshyam on 8/3/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol DateDelegate <NSObject>
-(void)dateCancelled:(id)referenceObj;
-(void)dateDidSelect:(NSDate *)selectedDate referenceObj:(id)referenceObj;
@end


@interface DatePickerView : UIView

/**
 *  Reference to object which conforms to DateDelegate Interface
 */
@property(nonatomic,weak)               id<DateDelegate>        delegate;


/**
 *  Control View presentation
 */
@property(nonatomic,strong) IBOutlet    UIView                      *view;

/**
 *  Reference to Cancel , used to cancel date selection
 */
@property(nonatomic,weak)   IBOutlet    UIBarButtonItem             *btnCancel;

/**
 *  Reference to Done , used to done date selection
 */
@property(nonatomic,weak)   IBOutlet    UIBarButtonItem             *btnDone;

/**
 *  Reference to Header Label , used to show date selection cause
 */
@property(nonatomic,weak)   IBOutlet    UILabel                     *lblHeader;

/**
 *  Caller reference which cause date selection to appear
 */
@property(nonatomic,weak)               id                          callingObj;

/**
 *  Boolean identifier which say whether Date Picker view is showing or not
 */
@property(nonatomic,assign)             BOOL                        showing;

/**
 *  Title String representation
 */
@property(nonatomic,strong)             NSString                    *strTitle;


/**
 *  Reference to date picker view
 */
@property (nonatomic,weak)    IBOutlet       UIDatePicker                *datePicker;



/**
 *  Used to configure or set up date picker
 */
-(void)setUpDatePickerWithDate:(NSDate *)pickerDate;

@end
