//
//  DatePickerView.m
//  Boku
//
//  Created by Ghanshyam on 8/3/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import "DatePickerView.h"



@implementation DatePickerView

@synthesize strTitle = _strTitle;

#pragma mark - Getter & Setter
-(NSString *)strTitle{
    return _strTitle;
}

-(void)setStrTitle:(NSString *)strTitle{
    _strTitle = strTitle;
    NSLog(@"title is in setter%@",_strTitle);
    self.lblHeader.text = _strTitle;
}


#pragma mark - Super Class Methods

-(id)initWithFrame:(CGRect)frame color:(UIColor *)tColor{
    self = [super initWithFrame:frame];
    if (self) {
        [[NSBundle mainBundle] loadNibNamed:@"DatePickerView" owner:self options:nil];
        [self addSubview:self.view];
        [_lblHeader setText:_strTitle];
        
    }
    return self;
}

-(id)initWithCoder:(NSCoder *)aDecoder{
    self = [self initWithCoder:aDecoder];
    if (self) {
        [[NSBundle mainBundle] loadNibNamed:@"DatePickerView" owner:self options:nil];
        [self addSubview:self.view];

    }
    return self;
}

-(id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [[NSBundle mainBundle] loadNibNamed:@"DatePickerView" owner:self options:nil];
        [self addSubview:self.view];

    }
    return self;
}

-(void)drawRect:(CGRect)rect{
    [self.view setFrame:self.bounds];
    
    NSLog(@"view frame is %@",NSStringFromCGRect(self.view.frame));
    [_btnCancel setTintColor:UIColorFromRedGreenBlue(0.f, 171.f, 234.f)];
    [_btnDone setTintColor:UIColorFromRedGreenBlue(0.f, 171.f, 234.f)];
    
    [_lblHeader setText:_strTitle];
}


-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    self.strTitle = nil;
    // arrMenuOptions = nil;
    NSLog(@"custom calendar dealloc");
}


#pragma mark - Instance Methods

/**
 *  Used to cancel date selection
 *
 *  @param sender : object which is triggering date cancelation
 */
-(IBAction)cancelAction:(id)sender{
    if (_delegate != nil) {
        NSLog(@"delegate existing");
    }else{
        NSLog(@"delegate not existing");
    }
    if ([_delegate conformsToProtocol:@protocol(DateDelegate)] &&
        [_delegate respondsToSelector:@selector(dateCancelled:)]) {
        [_delegate dateCancelled:_callingObj];
    }
}

/**
 *  Used to finalize date selection
 *
 *  @param sender : object which is triggering date selection
 */
-(IBAction)doneAction:(id)sender{
    if ([_delegate conformsToProtocol:@protocol(DateDelegate)] &&
        [_delegate respondsToSelector:@selector(dateDidSelect:referenceObj:)]) {
        [_delegate dateDidSelect:_datePicker.date referenceObj:_callingObj];
    }
}

/**
 *  Used to configure or set up date picker
 */
-(void)setUpDatePickerWithDate:(NSDate *)pickerDate{
    self.datePicker.maximumDate = [NSDate date];
    
    NSDateFormatter*    dateFormatter = [[NSDateFormatter alloc] init];
    dateFormatter.timeZone = [NSTimeZone systemTimeZone];
    [dateFormatter setDateFormat:@"MM/dd/yyyy"];
    
    NSString *strDate = [dateFormatter stringFromDate:pickerDate];
    
    self.datePicker.date = [dateFormatter dateFromString:strDate];
}


@end
