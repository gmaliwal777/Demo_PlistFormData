//
//  Options.h
//  eCitizens
//
//  Created by Vankat Reddy on 13/03/15.
//  Copyright (c) 2015 Suchita. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Options : NSObject

@property (nonatomic,strong) NSString   *idVal;
@property (nonatomic,strong) NSString   *name;
@property (nonatomic,assign) BOOL       isSelected;

@end
