//
//  Login.h
//  Boku
//
//  Created by Ghanshyam on 7/30/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import <Foundation/Foundation.h>

@class BKFormField;

@interface Login : NSObject

/**
 *  Reference to input field email
 */
@property (nonatomic,strong)    BKFormField     *email;

/**
 *  Reference to input field password
 */
@property (nonatomic,strong)    BKFormField     *password;

@end
