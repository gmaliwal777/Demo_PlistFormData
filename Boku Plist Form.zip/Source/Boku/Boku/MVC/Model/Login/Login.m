//
//  Login.m
//  Boku
//
//  Created by Ghanshyam on 7/30/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import "Login.h"

@implementation Login

/**
 *  Used to validate property email , either it consist valid value or not
 *
 *  @param ioValue  : value to be validated
 *  @param outError : Error object says whether any error in validation
 *
 *  @return : return YES if validation get success or NO if validation gets failed
 */
-(BOOL)validateEmail:(id *)ioValue error:(NSError * __autoreleasing *)outError{
    
    if (*ioValue == nil || ((NSString *)*ioValue).length<=0) {
        
        NSDictionary *userInfo = @{NSLocalizedDescriptionKey : @"Please enter email address",NSLocalizedFailureReasonErrorKey:@"Email address can not be empty"};
        //NSString *strDomain = [NSString stringWithFormat:@"%@",RE];
        *outError = [[NSError alloc] initWithDomain:@"LOGING_ERROR_DOMAIN" code:LOGIN_INVALID_EMAIL userInfo:userInfo];
        return NO;
    }else{
        NSString *email = (NSString *)*ioValue;
        
        if (![CommonFunctions validateEmail:email]) {
            NSDictionary *userInfo = @{NSLocalizedDescriptionKey : @"Please enter valid email address",NSLocalizedFailureReasonErrorKey:@"Email address is not valid"};
            //NSString *strDomain = [NSString stringWithFormat:@"%@",RE];
            *outError = [[NSError alloc] initWithDomain:@"LOGING_ERROR_DOMAIN" code:LOGIN_INVALID_EMAIL userInfo:userInfo];
            return NO;
        }
    }
    return YES;
}



/**
 *  Used to validate property password , either it consist valid value or not
 *
 *  @param ioValue  : value to be validated
 *  @param outError : Error object says whether any error in validation
 *
 *  @return : return YES if validation get success or NO if validation gets failed
 */
-(BOOL)validatePassword:(id *)ioValue error:(NSError * __autoreleasing *)outError{
    if (*ioValue == nil || ((NSString *)*ioValue).length<=0) {
        
        NSDictionary *userInfo = @{NSLocalizedDescriptionKey : @"Please enter password",NSLocalizedFailureReasonErrorKey:@"Password can not be empty"};
        *outError = [[NSError alloc] initWithDomain:@"LOGING_ERROR_DOMAIN" code:LOGIN_INVALID_PASSWORD userInfo:userInfo];
        return NO;
    }else{
        NSString *password = (NSString *)*ioValue;
        
        if (![CommonFunctions validateBKPassword:password]) {
            NSDictionary *userInfo = @{NSLocalizedDescriptionKey : @"Password must be at least 6 characters",NSLocalizedFailureReasonErrorKey:@"Password is not valid"};
            *outError = [[NSError alloc] initWithDomain:@"LOGING_ERROR_DOMAIN" code:LOGIN_INVALID_PASSWORD userInfo:userInfo];
            return NO;
        }
    }
    return YES;
}


@end
