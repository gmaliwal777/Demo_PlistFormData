//
//  OTP.h
//  Boku
//
//  Created by Ashish Sharma on 01/08/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import <Foundation/Foundation.h>

@class BKFormField;

@interface OTP : NSObject

/**
 *  Reference to input field OTP
 */
@property (nonatomic,strong) BKFormField *otp;

/**
 *  Keeps system generated OTP , so it can be used to validate user input(OTP).
 */
@property (nonatomic,strong)    NSString    *systemOTP;


@end
