//
//  OTP.m
//  Boku
//
//  Created by Ashish Sharma on 01/08/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import "OTP.h"

@implementation OTP

/**
 *  Used to validate property otp , either it consist valid value or not
 *
 *  @param ioValue  : value to be validated
 *  @param outError : Error object says whether any error in validation
 *
 *  @return : return YES if validation get success or NO if validation gets failed
 */
-(BOOL)validateOtp:(id *)ioValue error:(NSError * __autoreleasing *)outError{
    if (*ioValue == nil || ((NSString *)*ioValue).length<=0) {
        
        NSDictionary *userInfo = @{NSLocalizedDescriptionKey : @"Please enter OTP",NSLocalizedFailureReasonErrorKey:@"OTP can not be empty"};
        *outError = [[NSError alloc] initWithDomain:@"OTP_ERROR_DOMAIN" code:INVALID_OTP userInfo:userInfo];
        return NO;
    }else{
        NSString *otpValue = (NSString *)*ioValue;
        
        if (![_systemOTP isEqualToString:otpValue]) {
            NSDictionary *userInfo = @{NSLocalizedDescriptionKey : @"You entered wrong OTP",NSLocalizedFailureReasonErrorKey:@"OTP is not valid"};
            *outError = [[NSError alloc] initWithDomain:@"OTP_ERROR_DOMAIN" code:INVALID_OTP userInfo:userInfo];
            return NO;
        }
    }
    return YES;
}


@end
