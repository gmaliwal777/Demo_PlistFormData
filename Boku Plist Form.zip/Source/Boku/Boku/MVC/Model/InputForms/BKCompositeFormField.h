//
//  BKCompositeFormField.h
//  TableViewFormDemo
//
//  Created by Ghanshyam on 7/29/15.
//  Copyright (c) 2015 Ghanshyam. All rights reserved.
//

#import <Foundation/Foundation.h>

@class BKFormField;

@interface BKCompositeFormField : NSObject{

}

/**
 *  Composite field key , it may be dummy or logical for handling
 */
@property (nonatomic,strong)    NSString    *key;

/**
 *  Composite Left form field
 */
@property (nonatomic,strong)    BKFormField     *leftFormField;


/**
 *  Compostie Right form field
 */
@property (nonatomic,strong)    BKFormField     *rightFormField;



@end
