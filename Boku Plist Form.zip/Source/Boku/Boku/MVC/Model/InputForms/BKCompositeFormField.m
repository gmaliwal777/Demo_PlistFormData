//
//  BKCompositeFormField.m
//  TableViewFormDemo
//
//  Created by Ghanshyam on 7/29/15.
//  Copyright (c) 2015 Ghanshyam. All rights reserved.
//

#import "BKCompositeFormField.h"

@implementation BKCompositeFormField

-(id)init{
    self = [super init];
    if (self) {
        
    }
    return self;
}

@end
