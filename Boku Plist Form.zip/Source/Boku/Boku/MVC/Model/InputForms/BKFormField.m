//
//  BKFormField.m
//  TableViewFormDemo
//
//  Created by Ghanshyam on 7/28/15.
//  Copyright (c) 2015 Ghanshyam. All rights reserved.
//

#import "BKFormField.h"

@implementation BKFormField

#pragma mark - Super Class Methods

/**
 *  Used to initialize BKFormField
 *
 *  @param gesture : Gesture Flag to say whether input control will have Gesture control or not
 *
 *  @return : Class Object
 */
-(id)initWithGesture:(BOOL)gesture{
    self = [super init];
    if (self) {
        if (gesture) {
            tapGesture = [[UITapGestureRecognizer alloc] init];
            tapGesture.cancelsTouchesInView = NO;
            [self.input addGestureRecognizer:tapGesture];
        }
    }
    return self;
}

-(void)dealloc{
    
}


#pragma mark - Instance Methods
/**
 *  Assigning Target and Selector to TapGesture
 *
 *  @param selector : Selector which will be called on tap
 *  @param target   : Class Object which is handler
 */
-(void)setTapGestureSelector:(SEL)selector withTarget:(id)target{
    
    NSString *message = [NSString stringWithFormat:@"%@ input is not having gesture enabling",self.key];
    NSAssert(tapGesture, message);
    
    [tapGesture addTarget:target action:selector];
}

@end
