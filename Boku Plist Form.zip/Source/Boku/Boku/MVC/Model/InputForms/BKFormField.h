//
//  BKFormField.h
//  TableViewFormDemo
//
//  Created by Ghanshyam on 7/28/15.
//  Copyright (c) 2015 Ghanshyam. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Macros.h"

@interface BKFormField : NSObject{
    /**
     *  Reference to TapGesture , if input control is having tapGesture control
     */
    UITapGestureRecognizer  *tapGesture;
}


/**
 *  Form Field key , like email / password etc
 */
@property (nonatomic,strong)    NSString    *key;

/**
 *  Form field input keyboard type , like numeric , alphanumeric
 */
@property (nonatomic,assign)    BKKeyBoardType         keyboardType;

/**
 *  keyboard return type for current input field
 */
@property (nonatomic,assign)    BKReturnKeyType         returnType;

/**
 *  Reference to input view , which is weak refered
 */
@property (nonatomic,weak)  id  input;

/**
 *  It define whether input type is TextField / Button or Label
 */
@property (nonatomic,strong)    NSString    *inputType;

/**
 *  Form field place holder , which is placed when form field is empty
 */
@property (nonatomic,strong)    NSString    *placeHolder;

/**
 *  Form field input is secured or not
 */
@property (nonatomic,assign)    BOOL    isSecured;

/**
 *  Form field input value
 */
@property (nonatomic,strong)    id    value;


/**
 *  Form field input is to be user interacted or not 
 */
@property (nonatomic,assign)    BOOL    userInteraction;




/**
 *  Used to initialize BKFormField
 *
 *  @param gesture : Gesture Flag to say whether input control will have Gesture control or not
 *
 *  @return : Class Object
 */
-(id)initWithGesture:(BOOL)gesture;


/**
 *  Assigning Target and Selector to TapGesture
 *
 *  @param selector : Selector which will be called on tap
 *  @param target   : Class Object which is handler
 */
-(void)setTapGestureSelector:(SEL)selector withTarget:(id)target;

@end
