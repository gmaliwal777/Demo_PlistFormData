//
//  Country.m
//  Boku
//
//  Created by Ghanshyam on 7/30/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import "Country.h"

@implementation Country

@synthesize isd_code = _isd_code;

#pragma mark - Super Class Methods
-(id)init{
    self = [super init];
    if (self) {
        //Default isFiltered is YES
        
        _isFiltered = YES;
    }
    return self;
}

#pragma mark - Setter & Getters
/**
 *  Custom ISDCode setter, so corresponding searchContent can be set
 *
 *  @param isd_code : ISDCode for country
 */
-(void)setIsd_code:(NSString *)isd_code{
    
    if (_isd_code == isd_code) {
        return;
    }
    
    
    _isd_code = isd_code;
    
    _searchContent = [NSString stringWithFormat:@"+%@",isd_code];
}


#pragma mark - Instance Methods
/**
 *  Used to set isFiltered Boolean identifier either YES/NO
 *
 *  @param isFiltered : Boolean identifier which is to be set
 */
-(void)setFilterValue:(NSNumber *)filterValue{
    _isFiltered = [filterValue intValue];
}

@end
