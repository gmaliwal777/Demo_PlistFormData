//
//  Country.h
//  Boku
//
//  Created by Ghanshyam on 7/30/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Country : NSObject

/**
 *  Reference to country_name
 */
@property (nonatomic,strong)    NSString    *country_name;

/**
 *  Reference to country_code
 */
@property (nonatomic,strong)    NSString    *country_code;

/**
 *  Reference to isd_code
 */
@property (nonatomic,strong)    NSString    *isd_code;


/**
 *  Boolean identifier which says whether country is already selected
 */
@property (nonatomic,assign)    BOOL        isSelected;

/**
 *  Put the content which is to be consisdered in searching functioning
 */
@property (nonatomic,strong)    NSString    *searchContent;


/**
 *  Boolean identifier which says country is filtered in searching criteria
 */
@property (nonatomic,assign)    BOOL        isFiltered;




/**
 *  Used to set isFiltered Boolean identifier either YES/NO
 *
 *  @param isFiltered : Boolean identifier which is to be set
 */
-(void)setFilterValue:(NSNumber *)filterValue;

@end
