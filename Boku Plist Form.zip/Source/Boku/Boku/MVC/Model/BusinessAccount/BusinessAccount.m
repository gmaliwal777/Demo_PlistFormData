//
//  BusinessAccount.m
//  Boku
//
//  Created by Ashish Sharma on 01/08/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import "BusinessAccount.h"

@implementation BusinessAccount


//BUSINESS_ACCOUNT_INVALID_COMPANY_NAME,
//BUSINESS_ACCOUNT_INVALID_COMPANY_ADDRESS,
//BUSINESS_ACCOUNT_INVALID_PHONE_NUMBER,
//BUSINESS_ACCOUNT_INVALID_HASH_TAGS


/**
 *  Used to validate property companyName , either it consist valid value or not
 *
 *  @param ioValue  : value to be validated
 *  @param outError : Error object says whether any error in validation
 *
 *  @return : return YES if validation get success or NO if validation gets failed
 */
-(BOOL)validateCompanyName:(id *)ioValue error:(NSError * __autoreleasing *)outError{
    if (*ioValue == nil || ((NSString *)*ioValue).length<=0) {
        
        NSDictionary *userInfo = @{NSLocalizedDescriptionKey : @"Please enter comapny name",NSLocalizedFailureReasonErrorKey:@"Company name can not be empty"};
        *outError = [[NSError alloc] initWithDomain:@"BUSINESS_ACCOUNT_ERROR_DOMAIN" code:BUSINESS_ACCOUNT_INVALID_COMPANY_NAME userInfo:userInfo];
        return NO;
    }
    return YES;
}


/**
 *  Used to validate property companyAddress , either it consist valid value or not
 *
 *  @param ioValue  : value to be validated
 *  @param outError : Error object says whether any error in validation
 *
 *  @return : return YES if validation get success or NO if validation gets failed
 */
-(BOOL)validateCompanyAddress:(id *)ioValue error:(NSError * __autoreleasing *)outError{
    if (*ioValue == nil || ((NSString *)*ioValue).length<=0) {
        
        NSDictionary *userInfo = @{NSLocalizedDescriptionKey : @"Please enter comapny address",NSLocalizedFailureReasonErrorKey:@"Company Address can not be empty"};
        *outError = [[NSError alloc] initWithDomain:@"BUSINESS_ACCOUNT_ERROR_DOMAIN" code:BUSINESS_ACCOUNT_INVALID_COMPANY_ADDRESS userInfo:userInfo];
        return NO;
    }
    return YES;
}


/**
 *  Used to validate property phone , either it consist valid value or not
 *
 *  @param ioValue  : value to be validated
 *  @param outError : Error object says whether any error in validation
 *
 *  @return : return YES if validation get success or NO if validation gets failed
 */
-(BOOL)validatePhoneNumber:(id *)ioValue error:(NSError * __autoreleasing *)outError{
    if (*ioValue == nil || ((NSString *)*ioValue).length<=0) {
        
        NSDictionary *userInfo = @{NSLocalizedDescriptionKey : @"Please enter phone number",NSLocalizedFailureReasonErrorKey:@"Phone Number can not be empty"};
        *outError = [[NSError alloc] initWithDomain:@"BUSINESS_ACCOUNT_ERROR_DOMAIN" code:BUSINESS_ACCOUNT_INVALID_PHONE_NUMBER userInfo:userInfo];
        return NO;
    }else{
        NSString *phone = (NSString *)*ioValue;
        
        if (![CommonFunctions validateBkPhoneNo:phone]) {
            NSDictionary *userInfo = @{NSLocalizedDescriptionKey : @"Please enter valid phone number , it should be 10 digits",NSLocalizedFailureReasonErrorKey:@"Phone Number is not valid"};
            *outError = [[NSError alloc] initWithDomain:@"BUSINESS_ACCOUNT_ERROR_DOMAIN" code:BUSINESS_ACCOUNT_INVALID_PHONE_NUMBER userInfo:userInfo];
            return NO;
        }
    }
    return YES;
}


/**
 *  Used to validate property hashTags , either it consist valid value or not
 *
 *  @param ioValue  : value to be validated
 *  @param outError : Error object says whether any error in validation
 *
 *  @return : return YES if validation get success or NO if validation gets failed
 */
-(BOOL)validateHashTags:(id *)ioValue error:(NSError * __autoreleasing *)outError{
    NSLog(@"hash value %@",((NSString *)*ioValue));
    if (*ioValue == nil || ((NSString *)*ioValue).length<=1) {
        
        NSDictionary *userInfo = @{NSLocalizedDescriptionKey : @"Please enter Hash Tags",NSLocalizedFailureReasonErrorKey:@"Hash tags required"};
        *outError = [[NSError alloc] initWithDomain:@"BUSINESS_ACCOUNT_ERROR_DOMAIN" code:BUSINESS_ACCOUNT_INVALID_HASH_TAGS userInfo:userInfo];
        return NO;
    }
    return YES;
}

@end
