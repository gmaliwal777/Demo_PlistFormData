//
//  BusinessAccount.h
//  Boku
//
//  Created by Ashish Sharma on 01/08/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import <Foundation/Foundation.h>

@class BKFormField;

@interface BusinessAccount : NSObject

/**
 *  Reference to input field company name
 */
@property (nonatomic,strong) BKFormField *companyName;

/**
 *  Reference to input field company address
 */
@property (nonatomic,strong) BKFormField *companyAddress;

/**
 *  Reference to input field phone number
 */
@property (nonatomic,strong) BKFormField *phoneNumber;

/**
 *  Reference to input field hash tags
 */
@property (nonatomic,strong) BKFormField *hashTags;

@end
