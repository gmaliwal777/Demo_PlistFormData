//
//  Register.m
//  Boku
//
//  Created by Ghanshyam on 7/30/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import "Register.h"
#import "BKFormField.h"
#import "BKCompositeFormField.h"

@implementation Register


/**
 *  Used to validate property country , either it consist valid value or not
 *
 *  @param ioValue  : value to be validated
 *  @param outError : Error object says whether any error in validation
 *
 *  @return : return YES if validation get success or NO if validation gets failed
 */
-(BOOL)validateTerms_acceptance:(id *)ioValue error:(NSError * __autoreleasing *)outError{
    
    NSLog(@"value is %@",((NSNumber *)*ioValue));
    
    if (*ioValue == nil || ![((NSNumber *)*ioValue) boolValue]) {
        
        NSDictionary *userInfo = @{NSLocalizedDescriptionKey : @"Please accept Terms & Conditions",NSLocalizedFailureReasonErrorKey:@"Terms & Condition"};
        //NSString *strDomain = [NSString stringWithFormat:@"%@",RE];
        *outError = [[NSError alloc] initWithDomain:@"REGISTRATION_ERROR_DOMAIN" code:REGISTRATION_INVALID_TERMS userInfo:userInfo];
        return NO;
    }
    return YES;
}


/**
 *  Used to validate property country , either it consist valid value or not
 *
 *  @param ioValue  : value to be validated
 *  @param outError : Error object says whether any error in validation
 *
 *  @return : return YES if validation get success or NO if validation gets failed
 */
-(BOOL)validateCountry:(id *)ioValue error:(NSError * __autoreleasing *)outError{
    
    if (*ioValue == nil) {
        
        NSDictionary *userInfo = @{NSLocalizedDescriptionKey : @"Please select your country",NSLocalizedFailureReasonErrorKey:@"Country is required to locate you"};
        //NSString *strDomain = [NSString stringWithFormat:@"%@",RE];
        *outError = [[NSError alloc] initWithDomain:@"REGISTRATION_ERROR_DOMAIN" code:REGISTRATION_INVALID_COUNTRY userInfo:userInfo];
        return NO;
    }
    return YES;
}



/**
 *  Used to validate property phone , either it consist valid value or not
 *
 *  @param ioValue  : value to be validated
 *  @param outError : Error object says whether any error in validation
 *
 *  @return : return YES if validation get success or NO if validation gets failed
 */
-(BOOL)validatePhone:(id *)ioValue error:(NSError * __autoreleasing *)outError{
    if (*ioValue == nil || ((NSString *)*ioValue).length<=0) {
        
        NSDictionary *userInfo = @{NSLocalizedDescriptionKey : @"Please enter phone number",NSLocalizedFailureReasonErrorKey:@"Phone Number can not be empty"};
        *outError = [[NSError alloc] initWithDomain:@"REGISTRATION_ERROR_DOMAIN" code:REGISTRATION_INVALID_PHONE userInfo:userInfo];
        return NO;
    }else{
        NSString *phone = (NSString *)*ioValue;
        
        if (![CommonFunctions validateBkPhoneNo:phone]) {
            NSDictionary *userInfo = @{NSLocalizedDescriptionKey : @"Please enter valid phone number , it should be 10 digits",NSLocalizedFailureReasonErrorKey:@"Phone Number is not valid"};
            *outError = [[NSError alloc] initWithDomain:@"REGISTRATION_ERROR_DOMAIN" code:REGISTRATION_INVALID_PHONE userInfo:userInfo];
            return NO;
        }
    }
    return YES;
}


/**
 *  Used to validate property email , either it consist valid value or not
 *
 *  @param ioValue  : value to be validated
 *  @param outError : Error object says whether any error in validation
 *
 *  @return : return YES if validation get success or NO if validation gets failed
 */
-(BOOL)validateEmail:(id *)ioValue error:(NSError * __autoreleasing *)outError{
    
    if (*ioValue == nil || ((NSString *)*ioValue).length<=0) {
        
        NSDictionary *userInfo = @{NSLocalizedDescriptionKey : @"Please enter email address",NSLocalizedFailureReasonErrorKey:@"Email address can not be empty"};
        //NSString *strDomain = [NSString stringWithFormat:@"%@",RE];
        *outError = [[NSError alloc] initWithDomain:@"LOGING_ERROR_DOMAIN" code:REGISTRATION_INVALID_EMAIL userInfo:userInfo];
        return NO;
    }else{
        NSString *email = (NSString *)*ioValue;
        
        if (![CommonFunctions validateEmail:email]) {
            NSDictionary *userInfo = @{NSLocalizedDescriptionKey : @"Please enter valid email address",NSLocalizedFailureReasonErrorKey:@"Email address is not valid"};
            //NSString *strDomain = [NSString stringWithFormat:@"%@",RE];
            *outError = [[NSError alloc] initWithDomain:@"LOGING_ERROR_DOMAIN" code:REGISTRATION_INVALID_EMAIL userInfo:userInfo];
            return NO;
        }
    }
    return YES;
}

/**
 *  Used to validate property password , either it consist valid value or not
 *
 *  @param ioValue  : value to be validated
 *  @param outError : Error object says whether any error in validation
 *
 *  @return : return YES if validation get success or NO if validation gets failed
 */
-(BOOL)validatePassword:(id *)ioValue error:(NSError * __autoreleasing *)outError{
    if (*ioValue == nil || ((NSString *)*ioValue).length<=0) {
        
        NSDictionary *userInfo = @{NSLocalizedDescriptionKey : @"Please enter password",NSLocalizedFailureReasonErrorKey:@"Password can not be empty"};
        *outError = [[NSError alloc] initWithDomain:@"REGISTRATION_ERROR_DOMAIN" code:REGISTRATION_INVALID_PASSWORD userInfo:userInfo];
        return NO;
    }else{
        NSString *password = (NSString *)*ioValue;
        
        if (![CommonFunctions validateBKPassword:password]) {
            NSDictionary *userInfo = @{NSLocalizedDescriptionKey : @"Password must be at least 6 characters",NSLocalizedFailureReasonErrorKey:@"Password is not valid"};
            *outError = [[NSError alloc] initWithDomain:@"REGISTRATION_ERROR_DOMAIN" code:REGISTRATION_INVALID_PASSWORD userInfo:userInfo];
            return NO;
        }
    }
    return YES;
}



/**
 *  Used to validate property confirm_password , either it consist valid value or not
 *
 *  @param ioValue  : value to be validated
 *  @param outError : Error object says whether any error in validation
 *
 *  @return : return YES if validation get success or NO if validation gets failed
 */
-(BOOL)validateConfirm_password:(id *)ioValue error:(NSError * __autoreleasing *)outError{
    if (*ioValue == nil || ((NSString *)*ioValue).length<=0) {
        
        NSDictionary *userInfo = @{NSLocalizedDescriptionKey : @"Please enter confirm password",NSLocalizedFailureReasonErrorKey:@"Confirm password can not be empty"};
        *outError = [[NSError alloc] initWithDomain:@"REGISTRATION_ERROR_DOMAIN" code:REGISTRATION_INVALID_CONFIRM_PASSWORD userInfo:userInfo];
        return NO;
    }else{
        NSString *cPassword = (NSString *)*ioValue;
        
        if (![CommonFunctions validateBKPassword:cPassword]) {
            NSDictionary *userInfo = @{NSLocalizedDescriptionKey : @"Confirm Password must be at least 6 characters",NSLocalizedFailureReasonErrorKey:@"Confirm Password is not valid"};
            *outError = [[NSError alloc] initWithDomain:@"REGISTRATION_ERROR_DOMAIN" code:REGISTRATION_INVALID_CONFIRM_PASSWORD userInfo:userInfo];
            return NO;
        }else if (![_password.value isEqualToString:cPassword]){
            //Password and confirm password mis-matching
            NSDictionary *userInfo = @{NSLocalizedDescriptionKey : @"Password & Confirm-Password are not same",NSLocalizedFailureReasonErrorKey:@"Confirm Password is not valid"};
            *outError = [[NSError alloc] initWithDomain:@"REGISTRATION_ERROR_DOMAIN" code:REGISTRATION_INVALID_CONFIRM_PASSWORD userInfo:userInfo];
            return NO;
        }
    }
    return YES;
}


@end
