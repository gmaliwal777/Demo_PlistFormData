//
//  Register.h
//  Boku
//
//  Created by Ghanshyam on 7/30/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import <Foundation/Foundation.h>

@class BKFormField;

@interface Register : NSObject

/**
 *  Reference to country input field
 */
@property (nonatomic,strong)    BKFormField     *country;

/**
 *  Reference to phone input field
 */
@property (nonatomic,strong)    BKFormField     *phone;

/**
 *  Reference to email input field
 */
@property (nonatomic,strong)    BKFormField     *email;

/**
 *  Reference to password input field
 */
@property (nonatomic,strong)    BKFormField     *password;

/**
 *  Reference to confirm_password input field
 */
@property (nonatomic,strong)    BKFormField     *confirm_password;

/**
 *  Reference to invite_code input field
 */
@property (nonatomic,strong)    BKFormField     *invite_code;


/**
 *  Reference to terms_acceptance input field which is of button type
 */
@property (nonatomic,strong)    BKFormField     *terms_acceptance;

@end
