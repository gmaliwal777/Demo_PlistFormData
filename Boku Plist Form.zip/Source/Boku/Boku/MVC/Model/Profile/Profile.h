//
//  Profile.h
//  Boku
//
//  Created by Ghanshyam on 8/3/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import <Foundation/Foundation.h>

@class BKFormField;
@class BKCompositeFormField;

@interface Profile : NSObject

/**
 *  Reference to input field User Name
 */
@property (nonatomic,strong)    BKFormField    *name;

/**
 *  Reference to input field Email Address
 */
@property (nonatomic,strong)    BKFormField    *email;

/**
 *  Reference to composite input field Bio which consist (Gender & Birthday)
 */
@property (nonatomic,strong)    BKCompositeFormField    *bio;

/**
 *  Reference to input field User Location
 */
@property (nonatomic,strong)    BKFormField     *location;

/**
 *  Reference to input field User Mood Status
 */
@property (nonatomic,strong)    BKFormField     *mood_status;

/**
 *  Reference to input field Hash Tags
 */
@property (nonatomic,strong)    BKFormField     *hash_tags;


@end
