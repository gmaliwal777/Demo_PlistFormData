//
//  Profile.m
//  Boku
//
//  Created by Ghanshyam on 8/3/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import "Profile.h"
#import "BKCompositeFormField.h"
#import "BKFormField.h"

@implementation Profile

/**
 *  Used to validate property name , either it consist valid value or not
 *
 *  @param ioValue  : value to be validated
 *  @param outError : Error object says whether any error in validation
 *
 *  @return : return YES if validation get success or NO if validation gets failed
 */
-(BOOL)validateName:(id *)ioValue error:(NSError * __autoreleasing *)outError{
    
    if (ioValue == nil || ((NSString *)*ioValue).length<=0) {
        //Name should be there
        
        NSDictionary *userInfo = @{NSLocalizedDescriptionKey : @"Please enter your name",NSLocalizedFailureReasonErrorKey:@"User name can not be empty"};
        //NSString *strDomain = [NSString stringWithFormat:@"%@",RE];
        *outError = [[NSError alloc] initWithDomain:@"PROFILE_ERROR_DOMAIN" code:PROFILE_INVALID_NAME userInfo:userInfo];
        return NO;
    }
    return YES;
}


/**
 *  Used to validate property location , either it consist valid value or not
 *
 *  @param ioValue  : value to be validated
 *  @param outError : Error object says whether any error in validation
 *
 *  @return : return YES if validation get success or NO if validation gets failed
 */
-(BOOL)validateLocation:(id *)ioValue error:(NSError * __autoreleasing *)outError{
    
    if (ioValue == nil || ((NSString *)*ioValue).length<=0) {
        //Name should be there
        
        NSDictionary *userInfo = @{NSLocalizedDescriptionKey : @"Please enter your location",NSLocalizedFailureReasonErrorKey:@"Location can not be empty"};
        //NSString *strDomain = [NSString stringWithFormat:@"%@",RE];
        *outError = [[NSError alloc] initWithDomain:@"PROFILE_ERROR_DOMAIN" code:PROFILE_INVALID_LOCATION userInfo:userInfo];
        return NO;
    }
    return YES;
}



/**
 *  Used to validate property mood_status , either it consist valid value or not
 *
 *  @param ioValue  : value to be validated
 *  @param outError : Error object says whether any error in validation
 *
 *  @return : return YES if validation get success or NO if validation gets failed
 */
-(BOOL)validateMood_status:(id *)ioValue error:(NSError * __autoreleasing *)outError{
    
    if (ioValue == nil || ((NSString *)*ioValue).length<=0) {
        //Name should be there
        
        NSDictionary *userInfo = @{NSLocalizedDescriptionKey : @"Please enter your status",NSLocalizedFailureReasonErrorKey:@"Status can not be empty"};
        //NSString *strDomain = [NSString stringWithFormat:@"%@",RE];
        *outError = [[NSError alloc] initWithDomain:@"PROFILE_ERROR_DOMAIN" code:PROFILE_INVALID_MOOD_STATUS userInfo:userInfo];
        return NO;
    }
    return YES;
}


/**
 *  Used to validate property gender , either it consist valid value or not
 *
 *  @param ioValue  : value to be validated
 *  @param outError : Error object says whether any error in validation
 *
 *  @return : return YES if validation get success or NO if validation gets failed
 */
-(BOOL)validateGender:(id *)ioValue error:(NSError * __autoreleasing *)outError{
    
    if (ioValue == nil || ((NSString *)*ioValue).length<=0) {
        //Name should be there
        
        NSDictionary *userInfo = @{NSLocalizedDescriptionKey : @"Please select your Gender",NSLocalizedFailureReasonErrorKey:@"Gender can not be empty"};
        //NSString *strDomain = [NSString stringWithFormat:@"%@",RE];
        *outError = [[NSError alloc] initWithDomain:@"PROFILE_ERROR_DOMAIN" code:PROFILE_INVALID_BIO userInfo:userInfo];
        return NO;
    }
    return YES;
}


/**
 *  Used to validate property gender , either it consist valid value or not
 *
 *  @param ioValue  : value to be validated
 *  @param outError : Error object says whether any error in validation
 *
 *  @return : return YES if validation get success or NO if validation gets failed
 */
-(BOOL)validateBirthday:(id *)ioValue error:(NSError * __autoreleasing *)outError{
    
    if (ioValue == nil || ((NSString *)*ioValue).length<=0) {
        //Name should be there
        
        NSDictionary *userInfo = @{NSLocalizedDescriptionKey : @"Please enter your Birthday",NSLocalizedFailureReasonErrorKey:@"Birthday can not be empty"};
        //NSString *strDomain = [NSString stringWithFormat:@"%@",RE];
        *outError = [[NSError alloc] initWithDomain:@"PROFILE_ERROR_DOMAIN" code:PROFILE_INVALID_BIO userInfo:userInfo];
        return NO;
    }
    return YES;
}


/**
 *  Used to validate property email , either it consist valid value or not
 *
 *  @param ioValue  : value to be validated
 *  @param outError : Error object says whether any error in validation
 *
 *  @return : return YES if validation get success or NO if validation gets failed
 */
-(BOOL)validateEmail:(id *)ioValue error:(NSError * __autoreleasing *)outError{
    
    if (*ioValue == nil || ((NSString *)*ioValue).length<=0) {
        
        NSDictionary *userInfo = @{NSLocalizedDescriptionKey : @"Please enter email address",NSLocalizedFailureReasonErrorKey:@"Email address can not be empty"};
        //NSString *strDomain = [NSString stringWithFormat:@"%@",RE];
        *outError = [[NSError alloc] initWithDomain:@"PROFILE_ERROR_DOMAIN" code:PROFILE_INVALID_EMAIL userInfo:userInfo];
        return NO;
    }else{
        NSString *email = (NSString *)*ioValue;
        
        if (![CommonFunctions validateEmail:email]) {
            NSDictionary *userInfo = @{NSLocalizedDescriptionKey : @"Please enter valid email address",NSLocalizedFailureReasonErrorKey:@"Email address is not valid"};
            //NSString *strDomain = [NSString stringWithFormat:@"%@",RE];
            *outError = [[NSError alloc] initWithDomain:@"PROFILE_ERROR_DOMAIN" code:PROFILE_INVALID_EMAIL userInfo:userInfo];
            return NO;
        }
    }
    return YES;
}


/**
 *  Used to validate property hashTags , either it consist valid value or not
 *
 *  @param ioValue  : value to be validated
 *  @param outError : Error object says whether any error in validation
 *
 *  @return : return YES if validation get success or NO if validation gets failed
 */
-(BOOL)validateHash_tags:(id *)ioValue error:(NSError * __autoreleasing *)outError{
    NSLog(@"hash value %@",((NSString *)*ioValue));
    if (*ioValue == nil || ((NSString *)*ioValue).length<=1) {
        
        NSDictionary *userInfo = @{NSLocalizedDescriptionKey : @"Please enter Hash Tags",NSLocalizedFailureReasonErrorKey:@"Hash tags required"};
        *outError = [[NSError alloc] initWithDomain:@"PROFILE_ERROR_DOMAIN" code:PROFILE_UNKOWN_HASH_TAGS userInfo:userInfo];
        return NO;
    }
    return YES;
}


@end
