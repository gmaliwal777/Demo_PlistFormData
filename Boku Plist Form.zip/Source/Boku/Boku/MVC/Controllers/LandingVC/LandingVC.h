//
//  LandingVC.h
//  Boku
//
//  Created by Ashish Sharma on 28/07/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LandingVC : UIViewController {
    /// background image view
    IBOutlet UIImageView *imageViewBackground;
    
    /// tour one image view
    IBOutlet UIImageView *imageViewTourOne;
    
    /// tour two image view
    IBOutlet UIImageView *imageViewTourTwo;
    
    /// tour three image view
    IBOutlet UIImageView *imageViewTourThree;
    
    /// login button
    IBOutlet UIButton *buttonLogin;
    
    /// horizontal scroll view for slider
    IBOutlet UIScrollView *scrollView;
}

@end
