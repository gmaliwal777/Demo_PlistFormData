//
//  LandingVC.m
//  Boku
//
//  Created by Ashish Sharma on 28/07/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import "LandingVC.h"

@class LoginVC;
@class RegisterVC;

@interface LandingVC ()

@end

@implementation LandingVC

#pragma mark - Super Class Methods

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
   
    [self setTitle:@""];
    
    if (IS_iPHONE_4S) {
        imageViewBackground.image = [UIImage imageNamed:@"tourBg4"];
        imageViewTourOne.image = [UIImage imageNamed:@"tourOne4"];
        imageViewTourTwo.image = [UIImage imageNamed:@"tourTwo4"];
        imageViewTourThree.image = [UIImage imageNamed:@"tourThree4"];
    }
    
    NSString *titleLoginButton = [buttonLogin titleForState:UIControlStateNormal];
    
    NSRange loginRange = [titleLoginButton rangeOfString:@"LOGIN"];
    
    NSMutableAttributedString *attributedTitle = [[NSMutableAttributedString alloc] initWithString:titleLoginButton];
    [attributedTitle addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"Gentona-SemiBold" size:13.f] range:loginRange];
    [attributedTitle addAttribute:NSForegroundColorAttributeName value:UIColorFromRedGreenBlue(64.f, 64.f, 64.f) range:NSMakeRange(0, titleLoginButton.length)];
    [attributedTitle addAttribute:NSForegroundColorAttributeName value:UIColorFromRedGreenBlue(0.f, 171.f, 234.f) range:loginRange];
    
    [buttonLogin setAttributedTitle:attributedTitle forState:UIControlStateNormal];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [[UIApplication sharedApplication] setStatusBarHidden:YES];
    
    [self.navigationController setNavigationBarHidden:YES];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
    CGSize sizeScrollView = scrollView.frame.size;
    [scrollView setContentSize:CGSizeMake(SCREEN_WIDTH*3, sizeScrollView.height)];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
