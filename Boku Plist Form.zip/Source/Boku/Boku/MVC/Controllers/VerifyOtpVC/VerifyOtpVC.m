//
//  VerifyOtpVC.m
//  Boku
//
//  Created by Ashish Sharma on 01/08/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import "VerifyOtpVC.h"
#import "OTP.h"
#import "BKFormField.h"
#import "InputFieldCell.h"
#import "AlertView.h"



@interface VerifyOtpVC ()

/**
 *  IBAction assign to confirm button
 *
 *  @param sender instance of caller
 */
- (IBAction)buttonConfirmTap:(id)sender;

/**
 *  IBAction assign to button resent OTP
 *
 *  @param sender instance of caller
 */
- (IBAction)buttonResendOtpTap:(id)sender;


/**
 *  Used to setup initial view presentation for OTP
 */
- (void)setUpView;

/**
 *  Used to validate User input for OTP
 */
-(BOOL)validateUserInputs;


/**
 *  Used to update User input into relevant Input Model
 *
 *  @param txtInput : current input being editing
 */
- (void)updateUserInput:(UITextField *)txtInput;

@end

@implementation VerifyOtpVC

#pragma mark - Super Class Methods

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    arrInputKeys = [[NSMutableArray alloc] init];
    otp = [[OTP alloc] init];
    
    
    [self setUpView];
    
    [self setUpOtpForm];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)dealloc{
    otp = nil;
    arrInputKeys = nil;
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    //This is temporary value , assign here OTP which is to be validate with user given OTP
    otp.systemOTP = @"1236";
}

#pragma mark - IBActions

- (IBAction)buttonConfirmTap:(id)sender {
    if ([self validateUserInputs]) {
        //Put code here to move on next context ,here validation get success
        NSLog(@"user otp is %@",otp.otp.value);
        NSLog(@"system otp is %@",otp.systemOTP);
    }
}

- (IBAction)buttonResendOtpTap:(id)sender {
    
}

#pragma mark - Instance Methods

/**
 *  Used to make Current Context UI non user interacted
 */
-(void)makeUINonUserInteracted{
    [self.view endEditing:YES];
}

/**
 *  Used to setup initial view presentation for OTP
 */
- (void)setUpView {
    
    [self setTitle:@"OTP"];
    
    [CommonFunctions addBackButtonInNavigationItem:self.navigationItem forNavigationController:self.navigationController withTarget:nil andSelector:nil];
    
    //TapGesture on TableView so , on tap keyboard can be made down
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(makeUINonUserInteracted)];
    [tableViewForm addGestureRecognizer:tapGesture];
    tapGesture.cancelsTouchesInView = NO;
}

/**
 *  Used to validate User input for OTP
 */
-(BOOL)validateUserInputs{
    NSError *error;
    int counter;
    for (counter=0; counter<arrInputKeys.count;counter++) {
        NSString *fieldKey = [arrInputKeys objectAtIndex:counter];
        
        id input = [otp valueForKey:fieldKey];
        if ([input isKindOfClass:[BKFormField class]]) {
            
            BKFormField *formField = (BKFormField *)input;
            NSString *fieldValue = formField.value;
            
            [otp validateValue:&fieldValue forKey:fieldKey error:&error];
        }
        
        if (error) {
            break;
        }
    }
    
    if (error) {
        //Validation failed at validating input at indexPath
        
        NSMutableArray *arrActions = [[NSMutableArray alloc] init];
        //Ok Button
        NSDictionary *dictTab = [[NSDictionary alloc] initWithObjectsAndKeys:@"OK",@"title",^{
            
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:counter inSection:0];
            [tableViewForm scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
            
            UITableViewCell* cell = [tableViewForm cellForRowAtIndexPath:indexPath];
            if (cell && [cell isKindOfClass:[InputFieldCell class]]) {
                InputFieldCell *inputCell = (InputFieldCell *)cell;
                [inputCell.textField becomeFirstResponder];
            }
            
        },@"action", nil];
        [arrActions addObject:dictTab];
        
        alert = [[AlertView alloc] init];
        [alert showAlertView:[error.userInfo objectForKey:NSLocalizedDescriptionKey] arrActions:arrActions];
        
        return NO;
    }else{
        return YES;
    }
}

/**
 *  Used to set up login form context
 */
- (void)setUpOtpForm {
    
    NSArray *arrInputs = [CommonFunctions convertInputsWithResource:@"OTP" toModelClass:[OTP class]];
    
    for (int counter = 0;counter<arrInputs.count;counter++) {
        id input = [arrInputs objectAtIndex:counter];
        if ([input isKindOfClass:[BKFormField class]]) {
            //input is of BKFormField type
            BKFormField *singleField = (BKFormField *)input;
            [otp setValue:singleField forKey:singleField.key];
            [arrInputKeys addObject:singleField.key];
        }
    }
}

/**
 *  Used to update User input into relevant Input Model
 *
 *  @param txtInput : current input being editing
 */
- (void)updateUserInput:(UITextField *)txtInput {
    
    id input = [otp valueForKey:[arrInputKeys objectAtIndex:txtInput.tag]];
    if ([input isKindOfClass:[BKFormField class]]) {
        BKFormField *inputField = (BKFormField *)input;
        inputField.value = txtInput.text;
    }
}

#pragma mark - UITableView Datasource and Delegate Methods

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return arrInputKeys.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return SCREEN_WIDTH*ROW_HEIGHT_MULTIPLIER;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    id input = [otp valueForKey:[arrInputKeys objectAtIndex:indexPath.row]];
    
    if ([input isKindOfClass:[BKFormField class]]) {
        
        BKFormField *inputField = (BKFormField *)input;
        
        static NSString *cellIdentifierInputFieldCell = @"InputFieldCell";
        
        
        InputFieldCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifierInputFieldCell];
        
        if (cell == nil) {
            cell = [[[NSBundle mainBundle] loadNibNamed:@"InputFieldCell" owner:self options:nil] lastObject];
            cell.textField.delegate = self;
        }
        
        //Assigning txtInput view to model for further referencing
        inputField.input = cell.textField;
        
        cell.textField.placeholder = inputField.placeHolder;
        
        //Keyboard Type
        NSInteger inputVal = inputField.keyboardType;
        cell.textField.keyboardType = inputVal;
        
        //Keyboard return key type
        NSInteger returnVal = inputField.returnType;
        cell.textField.returnKeyType = returnVal;
        
        
        //User Interaction
        cell.textField.userInteractionEnabled = inputField.userInteraction;
        
        
        if (inputField.isSecured) {
            cell.textField.secureTextEntry = YES;
        }
        
        //prefill if current input is having value
        cell.textField.text = inputField.value;
        
        
        //Assigning txtInput Cell row no as tag
        cell.textField.tag = indexPath.row;
        
        
        return cell;
    }
    
    return nil;
}

- (void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [self.view endEditing:YES];
}

#pragma mark - UITextField Delegate

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    
    
    
    NSString *completeText = textField.text;
    
    if (string.length > 0) {
        //User is giving input
        completeText = [completeText stringByAppendingString:string];
        
    }else{
        //User is removing input
        NSRange subRange = NSMakeRange(0, range.location);
        completeText = [completeText substringWithRange:subRange];
    }
    
    if (completeText.length>6) {
        //OTP is 6 digit characters
        return NO;
    }
    
    textField.text = completeText;
    
    
    //Updating Input Model for updated user input
    [self updateUserInput:textField];
    
    return NO;
}


@end
