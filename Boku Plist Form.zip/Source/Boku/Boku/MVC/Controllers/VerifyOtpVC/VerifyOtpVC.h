//
//  VerifyOtpVC.h
//  Boku
//
//  Created by Ashish Sharma on 01/08/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import <UIKit/UIKit.h>

@class OTP;
@class AlertView;


@interface VerifyOtpVC : UIViewController <UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate> {
    
    /// Reference to add business account table view form
    IBOutlet UITableView *tableViewForm;
    
    /**
     *  business account input model , used as per KVC norms
     */
    OTP *otp;
    
    /**
     *  array of input keys ,only those input fields which will be rendered
     */
    NSMutableArray *arrInputKeys;
    
    
    /**
     *  AlertView to give alert to User
     */
    AlertView       *alert;
    
}

@end
