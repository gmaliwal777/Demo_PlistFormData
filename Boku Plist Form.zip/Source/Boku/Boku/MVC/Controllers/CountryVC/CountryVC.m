//
//  CountryVC.m
//  Boku
//
//  Created by Ghanshyam on 7/31/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import "CountryVC.h"
#import "Country.h"
#import "CountryCell.h"
#import "BKFormField.h"


@interface CountryVC ()

/**
 *  Used to setup search icon in navigation bar
 */
- (void)addSearchButton;

/**
 *  Used to hide and show search bar
 */
- (void)buttonSearchTap;

/**
 *  Used to Move to selected previous country if any
 */
-(void)moveToSelectedCountry;

/**
 *  Used to set up country list contanier having country model
 */
-(void)setUpCountryList;


/**
 *  Country raw data is converted to relevant coutry model
 *
 *  @param dictCountry : representing country raw data
 */
-(void)setUpCountryModelForRowCountryData:(NSDictionary *)dictCountry;

@end

@implementation CountryVC

#pragma mark - UIViewController Life Cycle

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    
    //Default Initialization
    arrMutalbeCountries = [[NSMutableArray alloc] init];
    
    [self setUpView];
    
    [self setUpCountryList];
    
    [self addSearchButton];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    //Keyboardframe change notification
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardChangeFrameHandler:) name:UIKeyboardWillChangeFrameNotification object:nil];
    
    //Keyboard hide notification
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardHide:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    
    [self moveToSelectedCountry];
}

-(void)dealloc{
    arrMutalbeCountries = nil;
}

#pragma mark - Keyboard Notification


/**
 *  KeyBoardFrameChangeHanlder Notification handler, called when ever keyboard sizes changed
 *
 *  @param notification : consist notification detail
 */
- (void)keyboardChangeFrameHandler:(NSNotification *)notification {
    NSDictionary* info = [notification userInfo];
    
    if ([info objectForKey:@"UIKeyboardAnimationDurationUserInfoKey"]) {
        keyboardAnimationTime = [notification.userInfo[UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    }else{
        keyboardAnimationTime = 0.25;
    }
    
    NSValue* aValue = [info objectForKey:UIKeyboardFrameEndUserInfoKey ];
    CGSize keyboardSize = [aValue CGRectValue].size;
    NSMutableDictionary *dictMetaData = [NSMutableDictionary dictionary];
    [dictMetaData setObject:@"UnKnownKeyBoard" forKey:@"type"];
    [dictMetaData setObject:[NSNumber numberWithInt:keyboardSize.height] forKey:@"size"];
    [self keyboardChangeWithMetaData:dictMetaData];
}

/**
 *  KeyboardHide Notification handler , called when ever keyboard gets down or hide
 *
 *  @param notification : consist notification detail
 */
- (void)keyboardHide:(NSNotification *)notification {
    //we have to set constraints as below
    [UIView animateWithDuration:keyboardAnimationTime animations:^{
        [tableViewBottomConstraint setConstant:0.0f];
        [tableViewCountry.superview layoutIfNeeded];
    }];
}

/**
 *  Selector called to respond KeyboardFrameChange Notification
 *
 *  @param dictMetaData : Consist detail about notification
 */
- (void)keyboardChangeWithMetaData:(NSDictionary *)dictMetaData {
    NSLog(@"meta data is %@",dictMetaData);
    keyBoardHeight = [[dictMetaData valueForKey:@"size"] floatValue];
    
    //[self.bottomChatViewConstraint setConstant:keyBoardHeight];
    [UIView animateWithDuration:keyboardAnimationTime animations:^{
        [tableViewBottomConstraint setConstant:keyBoardHeight];
        [tableViewCountry.superview layoutIfNeeded];
    }];
}


#pragma mark - Instance Methods
/**
 *  Used to setup search icon in navigation bar
 */
- (void)addSearchButton {
    
    UIButton *buttonSearch = [[UIButton alloc] initWithFrame:CGRectMake(0.f, 0.f, 50.f, 44.f)];
    [buttonSearch setImage:[UIImage imageNamed:@"searchButton"] forState:UIControlStateNormal];
    [buttonSearch addTarget:self action:@selector(buttonSearchTap) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *barButtonRight = [[UIBarButtonItem alloc] initWithCustomView:buttonSearch];
    
    UIBarButtonItem *negativeSpacer = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    negativeSpacer.width = -16.f;
    
    [self.navigationItem setRightBarButtonItems:[NSArray arrayWithObjects:negativeSpacer,barButtonRight,nil]];
}

/**
 *  Used to hide and show search bar
 */
- (void)buttonSearchTap{
    
    float height = 0.f;
    
    if (heightConstraintSearchFieldView.constant == 0.f) {
        height = SCREEN_WIDTH*(34.f/320.f);
        
        textFieldSearch.text = @"";
    }else{
        //Here search bar is no longer visible so we make all countries as filtered
        [arrMutalbeCountries makeObjectsPerformSelector:NSSelectorFromString(@"setFilterValue:") withObject:[NSNumber numberWithBool:YES]];
        [tableViewCountry reloadData];
        textFieldSearch.text = @"";
        [textFieldSearch resignFirstResponder];
    }
    
    [UIView animateWithDuration:0.4f
                     animations:^{
                         heightConstraintSearchFieldView.constant = height;
                         [self.view layoutIfNeeded];
                     }];
}

/**
 *  Used to Move to selected previous country if any
 */
-(void)moveToSelectedCountry{
    if (self.countryField.value) {
        Country *previousCountry = (Country *)self.countryField.value;
        
        NSInteger index = [arrMutalbeCountries indexOfObject:previousCountry];
        
        NSIndexPath *selectedIndexPath = [NSIndexPath indexPathForRow:index inSection:0];
        
        [tableViewCountry scrollToRowAtIndexPath:selectedIndexPath atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
    }
}

/**
 *  Used to make Current Context UI non user interacted
 */
-(void)makeUINonUserInteracted{
    [self.view endEditing:YES];
}


/**
 *  Used to set up default UI Presentation
 */
-(void)setUpView{
    [self setTitle:@"Select Country"];
    
    
    //Adding back button on navigation bar
    [CommonFunctions addBackButtonInNavigationItem:self.navigationItem forNavigationController:self.navigationController withTarget:nil andSelector:nil];
    
    //TapGesture on TableView so , on tap keyboard can be made down
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(makeUINonUserInteracted)];
    [tableViewCountry addGestureRecognizer:tapGesture];
    tapGesture.cancelsTouchesInView = NO;
}


/**
 *  Used to set up country list contanier having country model
 */
-(void)setUpCountryList{
    NSString *inputFormPath = [[NSBundle mainBundle] pathForResource:@"Country" ofType:@"plist"];
    
    //Consist raw inputs from resource plist
    NSArray* arrCountries = [NSArray arrayWithContentsOfFile:inputFormPath];
    
    for (int counter = 0;counter<arrCountries.count;counter++) {
        [self setUpCountryModelForRowCountryData:[arrCountries objectAtIndex:counter]];
    }
    
    //Checking which country is selected previous , if any previous selected. showing that country pre selected.
    if (self.countryField.value) {
        //BKFormField value is Country here , so we cast to Country Model
        
        Country *previousCountry = (Country *)self.countryField.value;
        
        
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF.country_code == %@ and SELF.isd_code == %@",previousCountry.country_code,previousCountry.isd_code];
        
        NSArray *filteredCountry = [arrMutalbeCountries filteredArrayUsingPredicate:predicate];
        if (filteredCountry.count>0) {
            Country *country = [filteredCountry objectAtIndex:0];
            self.countryField.value = country;
            country.isSelected = YES;
        }
    }
}


/**
 *  Country raw data is converted to relevant coutry model
 *
 *  @param dictCountry : representing country raw data
 */
-(void)setUpCountryModelForRowCountryData:(NSDictionary *)dictCountry{
    NSLog(@"dictionary is %@",dictCountry);
    
    NSArray *arrModelProperties = [CommonFunctions getModelPropertiesToArray:[Country class]];
    
    NSArray *arrKeys = [dictCountry allKeys];
    
    Country *country = [[Country alloc] init];
    
    
    //Processing all country data key and adding those in model
    for (NSString *key in arrKeys) {
        
        //If model class is not having key which is in resource plist
        NSString *message = [NSString stringWithFormat:@"%@ model does not have property %@",NSStringFromClass([Country class]),key];
        NSAssert([arrModelProperties containsObject:key],message);
        
        [country setValue:[dictCountry objectForKey:key] forKey:key];
    }
    
    
    
    //Adding country model in mutable array container
    [arrMutalbeCountries addObject:country];
}


#pragma mark - UITableView Datasource and Delegate Methods


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    NSPredicate *fiterationPredicate = [NSPredicate predicateWithFormat:@"SELF.isFiltered == %@",[NSNumber numberWithBool:YES]];
    NSArray *arrData = [arrMutalbeCountries filteredArrayUsingPredicate:fiterationPredicate];
    
    NSLog(@"count is %d",(int)arrData.count);
    return [arrMutalbeCountries filteredArrayUsingPredicate:fiterationPredicate].count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return SCREEN_WIDTH*ROW_HEIGHT_MULTIPLIER;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *cellIdentifierInputFieldCell = @"CountryCell";
    
    CountryCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifierInputFieldCell];
    
    if (cell == nil) {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"CountryCell" owner:self options:nil] lastObject];
    }
    
    
    NSPredicate *fiterationPredicate = [NSPredicate predicateWithFormat:@"SELF.isFiltered == %@",[NSNumber numberWithBool:YES]];
    NSArray *arrVisibleCountries = [arrMutalbeCountries filteredArrayUsingPredicate:fiterationPredicate];
    
    
    Country *country = [arrVisibleCountries objectAtIndex:indexPath.row];
    cell.labelCountryName.text = country.country_name;
    
    cell.labelISDCode.text = [NSString stringWithFormat:@"+%@",country.isd_code];
    
    if (country.isSelected) {
        [cell.imgSelection setImage:[UIImage imageNamed:@"selectedCheckMark"]];
    }else{
        [cell.imgSelection setImage:nil];
    }
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSPredicate *fiterationPredicate = [NSPredicate predicateWithFormat:@"SELF.isFiltered == %@",[NSNumber numberWithBool:YES]];
    NSArray *arrVisibleCountries = [arrMutalbeCountries filteredArrayUsingPredicate:fiterationPredicate];
    
    Country *country = [arrVisibleCountries objectAtIndex:indexPath.row];
    country.isSelected = YES;
    
    self.countryField.value = country;
    
    //Moving back
    [self.navigationController popViewControllerAnimated:YES];
}


#pragma mark - UITextField Delegate
-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
    NSString *searchText = @"";
    if (string.length == 0) {
        //User is removing
        NSRange subrange;
        subrange = NSMakeRange(0, range.location);
        searchText = [textField.text substringWithRange:subrange];
    }else{
        //User is giving input in search bar
        searchText = [textField.text stringByAppendingString:string];
    }
    
    if (searchText.length>0) {
        //Filtering Persons container
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF.country_name BEGINSWITH[cd] %@ || SELF.isd_code BEGINSWITH[cd] %@ || SELF.searchContent BEGINSWITH[cd] %@",searchText,searchText,searchText];
        NSArray *arrfilteredCountries = [arrMutalbeCountries filteredArrayUsingPredicate:predicate];
        
        //making Country isFiltered to YES , these are those countries which are in search criteria
        [arrfilteredCountries makeObjectsPerformSelector:NSSelectorFromString(@"setFilterValue:") withObject:[NSNumber numberWithBool:YES]];
        
        NSPredicate *notFilter = [NSCompoundPredicate notPredicateWithSubpredicate:predicate];
        NSArray *arrNonFilteredCountries = [arrMutalbeCountries filteredArrayUsingPredicate:notFilter];
        
        
        //making Country isFiltered to NO , these are those countries which are not in search criteria
        [arrNonFilteredCountries makeObjectsPerformSelector:NSSelectorFromString(@"setFilterValue:") withObject:[NSNumber numberWithBool:NO]];
        
    }else if (searchText.length==0){
        
       //Here we don't have any input in search bar so we make all countries as filtered
        [arrMutalbeCountries makeObjectsPerformSelector:NSSelectorFromString(@"setFilterValue:") withObject:[NSNumber numberWithBool:YES]];
    }
    
    //Reloading country list again
    [tableViewCountry reloadData];
    
    
    return YES;
}


@end
