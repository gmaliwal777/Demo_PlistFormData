//
//  CountryVC.h
//  Boku
//
//  Created by Ghanshyam on 7/31/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import <UIKit/UIKit.h>

@class BKFormField;


@interface CountryVC : UIViewController<UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate>{
    
    /// Reference to country list table view container
    IBOutlet UITableView *tableViewCountry;
    
    /// Reference to search bar textfield
    IBOutlet    UITextField     *textFieldSearch;
    
    
    /// Search Field height constraint reference
    IBOutlet NSLayoutConstraint *heightConstraintSearchFieldView;
    
    
    /// Reference to tableview bottom constraint , so tableview can be adjusted in respond to keyboard .
    IBOutlet    NSLayoutConstraint  *tableViewBottomConstraint;
    
    /**
     *  Countries mutalbe array container
     */
    NSMutableArray     *arrMutalbeCountries;
    
    
    /**
     * keep keyboard animation time frame
     */
    NSTimeInterval keyboardAnimationTime;
    
    /**
     *  keyboard height , when keyboard appears on screen
     */
    float keyBoardHeight;
    
}


/**
 *  Weak reference to country input field where selected country value to be reflected
 */
@property (nonatomic,weak)  BKFormField     *countryField;


@end
