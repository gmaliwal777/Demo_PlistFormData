//
//  RegisterVC.m
//  Boku
//
//  Created by Ashish Sharma on 29/07/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import "RegisterVC.h"
#import "Register.h"
#import "BKFormField.h"
#import "InputFieldCell.h"
#import "AlertView.h"
#import "CountryVC.h"
#import "Country.h"
#import "VerifyOtpVC.h"
#import "AddBusinessAccountVC.h"
#import "CreateProfileVC.h"
#import "InviteContactsVC.h"
#import "ViewProfileVC.h"
#import <AddressBook/AddressBook.h>


@interface RegisterVC ()

/**
 *  IBAction assign to accept terms button
 *
 *  @param sender instance of caller
 */
- (IBAction)buttonAcceptTermsTap:(id)sender;

/**
 *  IBAction assign to buttonTerms
 *
 *  @param sender instance of caller
 */
- (IBAction)buttonTermsTap:(id)sender;

/**
 *  IBAction assign to confirm button
 *
 *  @param sender instance of caller
 */
- (IBAction)buttonConfirmTap:(id)sender;


/**
 *  Used to set up default configuration in LoginVC Context
 */
-(void)setUpDefaultConfiguration;

@end

@implementation RegisterVC

#pragma mark - Super Class Methods

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //Default Initialization
    arrInputKeys = [[NSMutableArray alloc] init];
    registration = [[Register alloc] init];
    
    
    [self setUpRegisterForm];
    
    
    [self setUpDefaultConfiguration];
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [[UIApplication sharedApplication] setStatusBarHidden:NO];
    
    [self.navigationController setNavigationBarHidden:NO];
    
    
    [self prefillCountry];
    
    //Keyboardframe change notification
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardChangeFrameHandler:) name:UIKeyboardWillChangeFrameNotification object:nil];
    
    //Keyboard hide notification
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardHide:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    arrInputKeys = nil;
    
    registration = nil;
}


// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    
    if ([[segue identifier] isEqualToString:@"COUNTRY_LIST_SEGUE_IDENTIFIER"])
    {
        CountryVC   *countryVC = (CountryVC *)[segue destinationViewController];
        countryVC.countryField = registration.country;
    }
}

#pragma mark - Blocks

void(^AddressBookUserPromptCompletion)(bool granted, CFErrorRef error) = ^(bool granted, CFErrorRef error){
    if(granted){
        dispatch_sync(dispatch_get_main_queue(), ^{
            UIStoryboard *sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            AppDelegate *appdelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
            InviteContactsVC *icvc = [sb instantiateViewControllerWithIdentifier:@"InviteContactsVC"];
            [appdelegate.navController showViewController:icvc sender:nil];
        });
    }
};


#pragma mark - IBActions

- (IBAction)buttonAcceptTermsTap:(UIButton *)btnSender {
    
    btnSender.selected = !btnSender.selected;
    
    registration.terms_acceptance.value = [NSNumber numberWithBool:btnSender.selected];
    
}

- (IBAction)buttonTermsTap:(id)sender {
    UIStoryboard *sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    
//    VerifyOtpVC *vovc = [sb instantiateViewControllerWithIdentifier:@"VerifyOtpVC"];
//    [self.navigationController showViewController:vovc sender:nil];
    

//    AddBusinessAccountVC *abavc = [sb instantiateViewControllerWithIdentifier:@"AddBusinessAccountVC"];
//    [self.navigationController showViewController:abavc sender:nil];
    
//    CreateProfileVC *cpvc = [sb instantiateViewControllerWithIdentifier:@"CreateProfileVC"];
//    [self.navigationController showViewController:cpvc sender:nil];
    
    
    ViewProfileVC *viewProfileVC = [sb instantiateViewControllerWithIdentifier:@"PROFILE_VIEW_STORYBOARD_ID"];
    [self.navigationController showViewController:viewProfileVC sender:nil];
    
    
//    if ([CommonFunctions isBKAuthorizedForAddressBookWithCompletionBlock:AddressBookUserPromptCompletion]) {
//        
//        //Access to Address book is given
//        InviteContactsVC *icvc = [sb instantiateViewControllerWithIdentifier:@"InviteContactsVC"];
//        [self.navigationController showViewController:icvc sender:nil];
//    }
    
}

- (IBAction)buttonConfirmTap:(id)sender {

    [self.view endEditing:YES];
    
    if ([self validateUserInputs]) {
        //Validation get succes , put code to move on next context
        
        NSLog(@"country is %@",registration.country.value);
        NSLog(@"phone is %@",registration.phone.value);
        NSLog(@"email is %@",registration.email.value);
        NSLog(@"password is %@",registration.password.value);
        NSLog(@"confirm password is %@",registration.confirm_password.value);
    }
}

#pragma mark - Keyboard Notification

/**
 *  KeyBoardFrameChangeHanlder Notification handler, called when ever keyboard sizes changed
 *
 *  @param notification : consist notification detail
 */
- (void)keyboardChangeFrameHandler:(NSNotification *)notification {
    NSDictionary* info = [notification userInfo];
    
    if ([info objectForKey:@"UIKeyboardAnimationDurationUserInfoKey"]) {
        keyboardAnimationTime = [notification.userInfo[UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    }else{
        keyboardAnimationTime = 0.25;
    }
    
    NSValue* aValue = [info objectForKey:UIKeyboardFrameEndUserInfoKey ];
    CGSize keyboardSize = [aValue CGRectValue].size;
    NSMutableDictionary *dictMetaData = [NSMutableDictionary dictionary];
    [dictMetaData setObject:@"UnKnownKeyBoard" forKey:@"type"];
    [dictMetaData setObject:[NSNumber numberWithInt:keyboardSize.height] forKey:@"size"];
    [self keyboardChangeWithMetaData:dictMetaData];
}

/**
 *  KeyboardHide Notification handler , called when ever keyboard gets down or hide
 *
 *  @param notification : consist notification detail
 */
- (void)keyboardHide:(NSNotification *)notification {
    //we have to set constraints as below
    [UIView animateWithDuration:keyboardAnimationTime animations:^{
        [cnstTableViewBottom setConstant:0.0f];
        [tableViewForm layoutIfNeeded];
    }];
}

/**
 *  Selector called to respond KeyboardFrameChange Notification
 *
 *  @param dictMetaData : Consist detail about notification
 */
- (void)keyboardChangeWithMetaData:(NSDictionary *)dictMetaData {
    NSLog(@"meta data is %@",dictMetaData);
    keyBoardHeight = [[dictMetaData valueForKey:@"size"] floatValue];
    
    //[self.bottomChatViewConstraint setConstant:keyBoardHeight];
    [UIView animateWithDuration:keyboardAnimationTime animations:^{
        [cnstTableViewBottom setConstant:keyBoardHeight];
        [tableViewForm layoutIfNeeded];
    }];
}


#pragma mark - Instance Methods

/**
 *  Used to make Current Context UI non user interacted
 */
-(void)makeUINonUserInteracted{
    [self.view endEditing:YES];
}


/**
 *  Used to show country data if any device suggested or manual selected
 */
-(void)prefillCountry{
    //filling selected country if any
    BKFormField *countryField = registration.country;
    if (countryField && countryField.value) {
        Country *country = countryField.value;
        
        UITextField *txtCountry = (UITextField *)countryField.input;
        txtCountry.text = [NSString stringWithFormat:@"%@ (+%@) ",country.country_name,country.isd_code];
    }
}

/**
 *  Used to set up default configuration in LoginVC Context
 */
-(void)setUpDefaultConfiguration{
    [self setTitle:@"Register"];
    
    [CommonFunctions addBackButtonInNavigationItem:self.navigationItem forNavigationController:self.navigationController withTarget:nil andSelector:nil];
    
    
    //Set attributed text for terms and condition button
    NSString *titleTermsButton = [buttonTerms titleForState:UIControlStateNormal];
    
    NSRange termsRange = [titleTermsButton rangeOfString:@"Terms & Conditions"];
    
    NSMutableAttributedString *attributedTitle = [[NSMutableAttributedString alloc] initWithString:titleTermsButton];
    [attributedTitle addAttribute:NSForegroundColorAttributeName value:UIColorFromRedGreenBlue(64.f, 64.f, 64.f) range:NSMakeRange(0, titleTermsButton.length)];
    [attributedTitle addAttribute:NSForegroundColorAttributeName value:UIColorFromRedGreenBlue(0.f, 171.f, 234.f) range:termsRange];
    
    [buttonTerms setAttributedTitle:attributedTitle forState:UIControlStateNormal];
    
    
    
    //TapGesture on TableView so , on tap keyboard can be made down
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(makeUINonUserInteracted)];
    [tableViewForm addGestureRecognizer:tapGesture];
    tapGesture.cancelsTouchesInView = NO;
    
    
    
    //Device Country code as auto filled
    NSLocale *locale = [NSLocale currentLocale];
    NSString *countryCode = [locale objectForKey:NSLocaleCountryCode];
    NSLog(@" == %@",countryCode);
    
    if (countryCode) {
        NSString *inputCountryPath = [[NSBundle mainBundle] pathForResource:@"Country" ofType:@"plist"];
        
        //Consist raw country inputs from resource plist
        NSArray* arrCountries = [NSArray arrayWithContentsOfFile:inputCountryPath];
        
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF.country_code == %@",countryCode];
        
        NSArray *arrFilteredCountry = [arrCountries filteredArrayUsingPredicate:predicate];
        
        if (arrFilteredCountry.count>0) {
            NSDictionary *dictCountry = [arrFilteredCountry objectAtIndex:0];
            
            NSLog(@"dict info is %@",dictCountry);
            registration.country.value = [self getCountryModelForDeviceLocale:dictCountry];
            
            [self prefillCountry];
        }
    }
}


/**
 *  Country raw data is converted to relevant coutry model
 *
 *  @param dictCountry : representing country raw data
 */
-(Country *)getCountryModelForDeviceLocale:(NSDictionary *)dictCountry{
    NSLog(@"dictionary is %@",dictCountry);
    
    NSArray *arrModelProperties = [CommonFunctions getModelPropertiesToArray:[Country class]];
    
    NSArray *arrKeys = [dictCountry allKeys];
    
    Country *country = [[Country alloc] init];
    
    
    //Processing all country data key and adding those in model
    for (NSString *key in arrKeys) {
        
        //If model class is not having key which is in resource plist
        NSString *message = [NSString stringWithFormat:@"%@ model does not have property %@",NSStringFromClass([Country class]),key];
        NSAssert([arrModelProperties containsObject:key],message);
        
        [country setValue:[dictCountry objectForKey:key] forKey:key];
    }
    
    return country;
}


/**
 *  Used to validate User input for registration
 */
- (BOOL)validateUserInputs {
    NSError *error;
    int counter;
    for (counter=0; counter<arrInputKeys.count+1;counter++) {
        NSString *fieldKey;
        if (counter<arrInputKeys.count) {
            //All tableview input text validation
            
            fieldKey = [arrInputKeys objectAtIndex:counter];
        }else{
            //Terms & condition acceptance validation
            fieldKey = registration.terms_acceptance.key;
        }
        
        id input = [registration valueForKey:fieldKey];
        if ([input isKindOfClass:[BKFormField class]]) {
            
            BKFormField *formField = (BKFormField *)input;
            id fieldValue = formField.value;
            
            [registration validateValue:&fieldValue forKey:fieldKey error:&error];
            
        }
        
        if (error) {
            break;
        }
        
    }
    
    if (error) {
        //Validation failed at validating input at indexPath
        
        NSMutableArray *arrActions = [[NSMutableArray alloc] init];
        //Ok Button
        NSDictionary *dictTab = [[NSDictionary alloc] initWithObjectsAndKeys:@"OK",@"title",^{
            if (counter<arrInputKeys.count) {
                NSIndexPath *indexPath = [NSIndexPath indexPathForRow:counter inSection:0];
                [tableViewForm scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
                
                UITableViewCell* cell = [tableViewForm cellForRowAtIndexPath:indexPath];
                if (cell && [cell isKindOfClass:[InputFieldCell class]]) {
                    InputFieldCell *fieldCell = (InputFieldCell *)cell;
                    [fieldCell.textField becomeFirstResponder];
                    scrollingCompletionBlock = nil;
                }else{
                    scrollingCompletionBlock = ^{
                        UITableViewCell* cell = [tableViewForm cellForRowAtIndexPath:indexPath];
                        if (cell && [cell isKindOfClass:[InputFieldCell class]]) {
                            InputFieldCell *fieldCell = (InputFieldCell *)cell;
                            [fieldCell.textField becomeFirstResponder];
                        }
                    };
                }
            }
        },@"action", nil];
        [arrActions addObject:dictTab];
        
        alert = [[AlertView alloc] init];
        [alert showAlertView:[error.userInfo objectForKey:NSLocalizedDescriptionKey] arrActions:arrActions];
        
        return NO;
    }else{
        return YES;
    }
}

/**
 *  Used to set up login form context
 */
- (void)setUpRegisterForm {
    NSArray *arrInputs = [CommonFunctions convertInputsWithResource:@"Register" toModelClass:[Register class]];
    
    for (int counter = 0;counter<arrInputs.count;counter++) {
        id input = [arrInputs objectAtIndex:counter];
        if ([input isKindOfClass:[BKFormField class]]) {
            //input is of BKFormField type
            BKFormField *singleField = (BKFormField *)input;
            [registration setValue:singleField forKey:singleField.key];
            
            if ([singleField.inputType isEqualToString:BK_INPUT_TEXT]) {
                [arrInputKeys addObject:singleField.key];
            }
        }
    }
}

/**
 *  Used to update User input into relevant Input Model
 *
 *  @param txtInput : current input being editing
 */
- (void)updateUserInput:(UITextField *)txtInput {
    
    id input = [registration valueForKey:[arrInputKeys objectAtIndex:txtInput.tag]];
    if ([input isKindOfClass:[BKFormField class]]) {
        BKFormField *inputField = (BKFormField *)input;
        inputField.value = txtInput.text;
    }
}


#pragma mark - UITableView Datasource and Delegate Methods

- (void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView {
    if (scrollingCompletionBlock) {
        scrollingCompletionBlock();
    }
    scrollingCompletionBlock = nil;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return arrInputKeys.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return SCREEN_WIDTH*ROW_HEIGHT_MULTIPLIER;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    id input = [registration valueForKey:[arrInputKeys objectAtIndex:indexPath.row]];
    
    if ([input isKindOfClass:[BKFormField class]]) {
        
        BKFormField *inputField = (BKFormField *)input;
        
        static NSString *cellIdentifierInputFieldCell = @"InputFieldCell";
        
        
        InputFieldCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifierInputFieldCell];
        
        if (cell == nil) {
            cell = [[[NSBundle mainBundle] loadNibNamed:@"InputFieldCell" owner:self options:nil] lastObject];
            cell.textField.delegate = self;
        }
        
        //Assigning txtInput view to model for further referencing
        inputField.input = cell.textField;
        
        cell.textField.placeholder = inputField.placeHolder;
        
        //Keyboard Type
        NSInteger inputVal = inputField.keyboardType;
        cell.textField.keyboardType = inputVal;
        
        //Keyboard return key type
        NSInteger returnVal = inputField.returnType;
        cell.textField.returnKeyType = returnVal;
        
        //User Interaction
        cell.textField.userInteractionEnabled = inputField.userInteraction;
        
        
        if (inputField.isSecured) {
            cell.textField.secureTextEntry = YES;
        }
        
        if (inputField == registration.country) {
            if (inputField && inputField.value) {
                Country *country = inputField.value;
                
                UITextField *txtCountry = (UITextField *)inputField.input;
                txtCountry.text = [NSString stringWithFormat:@"%@ (+%@) ",country.country_name,country.isd_code];
            }
        }else{
            cell.textField.text = inputField.value;
        }
        
        //Assigning txtInput Cell row no as tag
        cell.textField.tag = indexPath.row;
        
        
        return cell;
    }
    
    return nil;
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    [self.view endEditing:YES];
    
    //Corresponding input field
    BKFormField *inputField = [registration valueForKey:[arrInputKeys objectAtIndex:indexPath.row]];
    
    
    if (!inputField.userInteraction) {
        //Selected input is not user interacted so put your code to have automated response for this input
        
        //Here we have only country as non-user interacted so we move to country list here
        
        
        [self performSegueWithIdentifier:@"COUNTRY_LIST_SEGUE_IDENTIFIER" sender:nil];
    }
}

#pragma mark - UITextField Delegate

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    
    NSString *completeText = textField.text;
    if (string.length>0) {
        //User is giving input
        completeText = [completeText stringByAppendingString:string];
        
    }else{
        //User is removing input
        NSRange subRange = NSMakeRange(0, range.location);
        completeText = [completeText substringWithRange:subRange];
    }
    
    textField.text = completeText;
    
    
    //Updating Input Model for updated user input
    [self updateUserInput:textField];
    
    
    return NO;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    NSInteger returnTypeVal = textField.returnKeyType;
    BKReturnKeyType returnType = returnTypeVal;
    if (returnType == BKReturnKeyDone) {
        [textField resignFirstResponder];
    }else if(returnType == BKReturnKeyNext){
        //Return type is next we will move to next input
        
        int currentRow = (int)textField.tag;
        if (currentRow+1<arrInputKeys.count) {
            //WE have more inputs to be made as become first responder
            NSIndexPath *nextIndexPath = [NSIndexPath indexPathForRow:currentRow+1 inSection:0];
            [tableViewForm scrollToRowAtIndexPath:nextIndexPath atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
            
            
            UITableViewCell *cell = [tableViewForm cellForRowAtIndexPath:nextIndexPath];
            if (cell && [cell isKindOfClass:[InputFieldCell class]]) {
                InputFieldCell *fieldCell = (InputFieldCell *)cell;
                [fieldCell.textField becomeFirstResponder];
                scrollingCompletionBlock = nil;
            }else{
                scrollingCompletionBlock = ^{
                    UITableViewCell* cell = [tableViewForm cellForRowAtIndexPath:nextIndexPath];
                    if (cell && [cell isKindOfClass:[InputFieldCell class]]) {
                        InputFieldCell *fieldCell = (InputFieldCell *)cell;
                        [fieldCell.textField becomeFirstResponder];
                    }
                };
            }
        }else{
            [textField resignFirstResponder];
        }
    }
    
    return YES;
}

@end
