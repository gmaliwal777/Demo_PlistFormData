//
//  RegisterVC.h
//  Boku
//
//  Created by Ashish Sharma on 29/07/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Register;
@class AlertView;

@interface RegisterVC : UIViewController<UITextFieldDelegate,UITableViewDataSource,UITableViewDelegate>{
    
    /// Reference to Register table view form
    IBOutlet UITableView *tableViewForm;
    
    /// reference to terms and condition button
    IBOutlet UIButton *buttonTerms;
    
    /// Reference to tableview bottom constraints
    IBOutlet NSLayoutConstraint *cnstTableViewBottom;
    
    /**
     *  array of input keys , only those much input fields will be rendered
     */
    NSMutableArray *arrInputKeys;
    
    
    /**
     *  login input model , used as per KVC norms
     */
    Register *registration;
    
    
    /**
     *  alertView to give alert to User
     */
    AlertView *alert;
    
    /**
     * keep keyboard animation time frame
     */
    NSTimeInterval keyboardAnimationTime;
    
    /**
     *  keyboard height , when keyboard appears on screen
     */
    float keyBoardHeight;
    
    
    /**
     *  Block which is to be executed on scrolling finished , Its useful to scroll particualr Input Field and make that input first Responder
     */
    void(^scrollingCompletionBlock)();
}

@end
