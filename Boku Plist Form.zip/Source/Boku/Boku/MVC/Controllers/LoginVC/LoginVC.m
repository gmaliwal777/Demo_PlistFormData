//
//  LoginVC.m
//  Boku
//
//  Created by Ashish Sharma on 29/07/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import "LoginVC.h"
#import "InputFieldCell.h"
#import "Login.h"
#import "BKFormField.h"
#import "BKCompositeFormField.h"
#import "AlertView.h"


@interface LoginVC ()

@end

@implementation LoginVC

#pragma mark - Super Class Methods

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //Default Initialization
    arrInputKeys = [[NSMutableArray alloc] init];
    login   = [[Login alloc] init];
    
    
    [self setUpDefaultConfiguration];
    
    
    [self setUpLoginForm];
    
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [[UIApplication sharedApplication] setStatusBarHidden:NO];
    
    [self.navigationController setNavigationBarHidden:NO];
    
    [tableViewForm setContentInset:UIEdgeInsetsMake(2.f, 0.f, 0.f, 0.f)];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)dealloc{
    arrInputKeys = nil;
    
    login = nil;
}

#pragma mark-- IBAction Methods

/**
 *  Selector used to login in App
 */
-(IBAction)loginAction{
    [self.view endEditing:YES];
    
    if ([self validateUserInputs]) {
        //Validation get succes , put code to move on next context
        NSLog(@"email is %@",login.email.value);
        NSLog(@"password is %@",login.password.value);
    }
}

#pragma mark- Instance Methods

/**
 *  Used to make Current Context UI non user interacted
 */
-(void)makeUINonUserInteracted{
    [self.view endEditing:YES];
}

/**
 *  Used to validate User input for registration
 */
-(BOOL)validateUserInputs{
    NSError *error;
    int counter;
    for (counter=0; counter<arrInputKeys.count;counter++) {
        NSString *fieldKey = [arrInputKeys objectAtIndex:counter];
        
        id input = [login valueForKey:fieldKey];
        if ([input isKindOfClass:[BKFormField class]]) {
            
            BKFormField *formField = (BKFormField *)input;
            NSString *fieldValue = formField.value;
            
            [login validateValue:&fieldValue forKey:fieldKey error:&error];
            
        }
        
        if (error) {
            break;
        }
        
    }
    
    if (error) {
        //Validation failed at validating input at indexPath
        
        NSMutableArray *arrActions = [[NSMutableArray alloc] init];
        //Ok Button
        NSDictionary *dictTab = [[NSDictionary alloc] initWithObjectsAndKeys:@"OK",@"title",^{
            
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:counter inSection:0];
            [tableViewForm scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
            
            UITableViewCell* cell = [tableViewForm cellForRowAtIndexPath:indexPath];
            if (cell && [cell isKindOfClass:[InputFieldCell class]]) {
                InputFieldCell *inputCell = (InputFieldCell *)cell;
                [inputCell.textField becomeFirstResponder];
            }
        },@"action", nil];
        [arrActions addObject:dictTab];
        
        alert = [[AlertView alloc] init];
        [alert showAlertView:[error.userInfo objectForKey:NSLocalizedDescriptionKey] arrActions:arrActions];
        
        
        return NO;
    }else{
        return YES;
    }
}



/**
 *  Used to update User input into relevant Input Model
 *
 *  @param txtInput : current input being editing
 */
-(void)updateUserInput:(UITextField *)txtInput{
    
    id input = [login valueForKey:[arrInputKeys objectAtIndex:txtInput.tag]];
    if ([input isKindOfClass:[BKFormField class]]) {
        BKFormField *inputField = (BKFormField *)input;
        inputField.value = txtInput.text;
    }
}

/**
 *  Used to set up login form context
 */
-(void)setUpLoginForm{
    NSArray *arrInputs = [CommonFunctions convertInputsWithResource:@"Login" toModelClass:[Login class]];
    
    for (int counter = 0;counter<arrInputs.count;counter++) {
        id input = [arrInputs objectAtIndex:counter];
        if ([input isKindOfClass:[BKFormField class]]) {
            //input is of BKFormField type
            BKFormField *singleField = (BKFormField *)input;
            [login setValue:singleField forKey:singleField.key];
            [arrInputKeys addObject:singleField.key];
        }
    }
}

/**
 *  Used to set up default configuration in LoginVC Context
 */
-(void)setUpDefaultConfiguration{
    [self setTitle:@"Login"];
    
    [CommonFunctions addBackButtonInNavigationItem:self.navigationItem forNavigationController:self.navigationController withTarget:nil andSelector:nil];
    
    NSString *titleForgotPasswordButton = [buttonForgotPassword titleForState:UIControlStateNormal];
    
    NSRange forgotPasswordRange = [titleForgotPasswordButton rangeOfString:@"Forgot Password?"];
    
    NSMutableAttributedString *attributedTitle = [[NSMutableAttributedString alloc] initWithString:titleForgotPasswordButton];
    [attributedTitle addAttribute:NSForegroundColorAttributeName value:UIColorFromRedGreenBlue(64.f, 64.f, 64.f) range:NSMakeRange(0, titleForgotPasswordButton.length)];
    [attributedTitle addAttribute:NSForegroundColorAttributeName value:UIColorFromRedGreenBlue(0.f, 171.f, 234.f) range:forgotPasswordRange];
    
    [buttonForgotPassword setAttributedTitle:attributedTitle forState:UIControlStateNormal];
    
    
    //TapGesture on TableView so , on tap keyboard can be made down
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(makeUINonUserInteracted)];
    [tableViewForm addGestureRecognizer:tapGesture];
    tapGesture.cancelsTouchesInView = NO;
}


#pragma mark - UITableView Datasource and Delegate Methods

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return arrInputKeys.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return SCREEN_WIDTH*ROW_HEIGHT_MULTIPLIER;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    id input = [login valueForKey:[arrInputKeys objectAtIndex:indexPath.row]];
    
    if ([input isKindOfClass:[BKFormField class]]) {
        
        BKFormField *inputField = (BKFormField *)input;
        
        static NSString *cellIdentifierInputFieldCell = @"InputFieldCell";
        
        
        InputFieldCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifierInputFieldCell];
        
        if (cell == nil) {
            cell = [[[NSBundle mainBundle] loadNibNamed:@"InputFieldCell" owner:self options:nil] lastObject];
            cell.textField.delegate = self;
        }
        
        //Assigning txtInput view to model for further referencing
        inputField.input = cell.textField;
        
        cell.textField.placeholder = inputField.placeHolder;
        
        //Keyboard Type
        NSInteger inputVal = inputField.keyboardType;
        cell.textField.keyboardType = inputVal;
        
        //Keyboard return key type
        NSInteger returnVal = inputField.returnType;
        cell.textField.returnKeyType = returnVal;
        
        
        //User Interaction
        cell.textField.userInteractionEnabled = inputField.userInteraction;
        
        
        if (inputField.isSecured) {
            cell.textField.secureTextEntry = YES;
        }
        
        //prefill if current input is having value
        cell.textField.text = inputField.value;
        
        
        //Assigning txtInput Cell row no as tag
        cell.textField.tag = indexPath.row;
        
        
        return cell;
    }
    
    return nil;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [self.view endEditing:YES];
}


#pragma mark--
#pragma mark-- UITextField Delegate

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
    NSString *completeText = textField.text;
    if (string.length>0) {
        //User is giving input
        completeText = [completeText stringByAppendingString:string];
        
    }else{
        //User is removing input
        NSRange subRange = NSMakeRange(0, range.location);
        completeText = [completeText substringWithRange:subRange];
    }
    
    textField.text = completeText;
    
    
    //Updating Input Model for updated user input
    [self updateUserInput:textField];
    
    return NO;
}


-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    NSInteger returnTypeVal = textField.returnKeyType;
    BKReturnKeyType returnType = returnTypeVal;
    if (returnType == BKReturnKeyDone) {
        [textField resignFirstResponder];
    }else if(returnType == BKReturnKeyNext){
        //Return type is next we will move to next input
        
        int currentRow = (int)textField.tag;
        if (currentRow+1<arrInputKeys.count) {
            //WE have more inputs to be made as become first responder
            NSIndexPath *nextIndexPath = [NSIndexPath indexPathForRow:currentRow+1 inSection:0];
            
            UITableViewCell *cell = [tableViewForm cellForRowAtIndexPath:nextIndexPath];
            
            if (cell && [cell isKindOfClass:[InputFieldCell class]]) {
                InputFieldCell *fieldCell = (InputFieldCell *)cell;
                [fieldCell.textField becomeFirstResponder];
            }
        }else{
            [textField resignFirstResponder];
        }
    }
    
    return YES;
}

@end
