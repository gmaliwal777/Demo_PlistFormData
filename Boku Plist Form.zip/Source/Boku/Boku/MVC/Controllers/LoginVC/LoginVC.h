//
//  LoginVC.h
//  Boku
//
//  Created by Ashish Sharma on 29/07/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Login;
@class AlertView;


@interface LoginVC : UIViewController <UITableViewDataSource, UITableViewDelegate,UITextFieldDelegate> {
    
    /// Reference to login table view form
    IBOutlet UITableView    *tableViewForm;
    
    /// Reference to forgot password
    IBOutlet UIButton       *buttonForgotPassword;

    /**
     *  array of input keys , only those much input fields will be rendered
     */
    NSMutableArray     *arrInputKeys;
    
    
    /**
     *  login input model , used as per KVC norms
     */
    Login       *login;
    
    
    /**
     *  AlertView to give alert to User
     */
    AlertView       *alert;
    
}

@end
