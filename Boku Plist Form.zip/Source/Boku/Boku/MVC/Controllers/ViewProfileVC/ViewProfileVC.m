//
//  ViewProfileVC.m
//  Boku
//
//  Created by Ghanshyam on 8/6/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import "ViewProfileVC.h"
#import "Profile.h"
#import "BusinessAccount.h"
#import "BKCompositeFormField.h"
#import "BKFormField.h"
#import "InputFieldCell.h"
#import "BioCell.h"

@interface ViewProfileVC ()

@end

@implementation ViewProfileVC

#define topViewHeightBase   0.36971

#pragma mark - Super Class Methods

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //Default Initialization
    arrBusinessInputKeys = [[NSMutableArray alloc] init];
    arrProfileInputKeys = [[NSMutableArray alloc] init];
    businessAccount = [[BusinessAccount alloc] init];
    profile = [[Profile alloc] init];
    
    
    [self setUpProfileForm];
    
    [self setUpBusinessForm];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)dealloc{
    businessAccount = nil;
    profile = nil;
    arrProfileInputKeys = nil;
    arrBusinessInputKeys = nil;
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    /**
     *  PUT Code which is to be executed once in current context .
     */
    dispatch_once(&dispatchCodeOnce, ^{
        [self setUpView];
    });
}


#pragma mark - Instance Methods
-(IBAction)profileInfoAction:(UIButton *)btnProfile{
    if (!btnProfileInfo.selected) {
        btnProfileInfo.selected = YES;
        btnBusinessInfo.selected = NO;
        
        [tableViewForm reloadData];
    }
}

-(IBAction)businessInfoAction:(UIButton *)btnBusiness{
    if (!btnBusinessInfo.selected) {
        btnProfileInfo.selected = NO;
        btnBusinessInfo.selected = YES;
        
        [tableViewForm reloadData];
    }
}


/**
 *  Used to setup defualt ui configuration
 */
- (void)setUpView {
    
    [self.navigationController setNavigationBarHidden:YES];
    
    //Adjusting table view header view height
    CGRect topViewFrame = tableViewTopView.frame;
    topViewFrame.size.height = topViewHeightBase*SCREEN_HEIGHT;
    tableViewTopView.frame = topViewFrame;
}


/**
 *  Used to set up profile form context
 */
- (void)setUpProfileForm {
    
    NSArray *arrInputs = [CommonFunctions convertInputsWithResource:@"Profile" toModelClass:[Profile class]];
    
    for (int counter = 0;counter<arrInputs.count;counter++) {
        id input = [arrInputs objectAtIndex:counter];
        if ([input isKindOfClass:[BKFormField class]]) {
            //input is of BKFormField type
            BKFormField *singleField = (BKFormField *)input;
            [profile setValue:singleField forKey:singleField.key];
            [arrProfileInputKeys addObject:singleField.key];
        }else if ([input isKindOfClass:[BKCompositeFormField class]]){
            
            BKCompositeFormField *compositeField = (BKCompositeFormField *)input;
            
            [profile setValue:compositeField forKey:compositeField.key];
            
            //Adding input key in arrProfileInputKeys , to have functioning later for Profile
            [arrProfileInputKeys addObject:compositeField.key];
        }
    }
}


/**
 *  Used to set up businessAccount form context
 */
- (void)setUpBusinessForm {
    
    NSArray *arrInputs = [CommonFunctions convertInputsWithResource:@"BusinessAccount" toModelClass:[BusinessAccount class]];
    
    for (int counter = 0;counter<arrInputs.count;counter++) {
        id input = [arrInputs objectAtIndex:counter];
        if ([input isKindOfClass:[BKFormField class]]) {
            //input is of BKFormField type
            BKFormField *singleField = (BKFormField *)input;
            [businessAccount setValue:singleField forKey:singleField.key];
            [arrBusinessInputKeys addObject:singleField.key];
        }else if ([input isKindOfClass:[BKCompositeFormField class]]){
            
            BKCompositeFormField *compositeField = (BKCompositeFormField *)input;
            
            [businessAccount setValue:compositeField forKey:compositeField.key];
            
            //Adding input key in arrBusinessInputKeys , to have functioning later for BusinessAccount
            [arrBusinessInputKeys addObject:compositeField.key];
        }
    }
}


#pragma mark - UITableView Datasource and Delegate Methods


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (btnProfileInfo.selected) {
        return arrProfileInputKeys.count;
    }else if(btnBusinessInfo.selected){
        return arrBusinessInputKeys.count;
    }
    return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return SCREEN_WIDTH*ROW_HEIGHT_MULTIPLIER;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    id input;
    
    if (btnProfileInfo.selected) {
        input = [profile valueForKey:[arrProfileInputKeys objectAtIndex:indexPath.row]];
    }else{
        input = [businessAccount valueForKey:[arrBusinessInputKeys objectAtIndex:indexPath.row]];
    }
    
    if ([input isKindOfClass:[BKFormField class]]) {
        
        BKFormField *inputField = (BKFormField *)input;
        
        static NSString *cellIdentifierInputFieldCell = @"InputFieldCell";
        
        
        InputFieldCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifierInputFieldCell];
        
        if (cell == nil) {
            cell = [[[NSBundle mainBundle] loadNibNamed:@"InputFieldCell" owner:self options:nil] lastObject];
        }
        
        //Assigning txtInput view to model for further referencing
        inputField.input = cell.textField;
        
        cell.textField.placeholder = inputField.placeHolder;
        
        //Keyboard Type
        NSInteger inputVal = inputField.keyboardType;
        cell.textField.keyboardType = inputVal;
        
        //Keyboard return key type
        NSInteger returnVal = inputField.returnType;
        cell.textField.returnKeyType = returnVal;
        
        
        //User Interaction disable , because it view part
        cell.textField.userInteractionEnabled = NO;
        
        
        if (inputField.isSecured) {
            cell.textField.secureTextEntry = YES;
        }
        
        //prefill if current input is having value
        cell.textField.text = inputField.value;
        
        
        //Assigning txtInput Cell row no as tag
        cell.textField.tag = indexPath.row;
        
        
        return cell;
    }else if([input isKindOfClass:[BKCompositeFormField class]]){
        
        BKCompositeFormField *compositeField = (BKCompositeFormField *)input;
        
        static NSString *cellIdentifierBioCell = @"BioCell";
        BioCell *cell = (BioCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifierBioCell];
        
        if (!cell) {
            cell = [[[NSBundle mainBundle] loadNibNamed:@"BioCell" owner:self options:nil] lastObject];
        }
        
        //>>>>Left Input
        compositeField.leftFormField.input = cell.textFieldGender;
        
        cell.textFieldGender.placeholder = compositeField.leftFormField.placeHolder;
        
        //Keyboard Type
        NSInteger inputVal = compositeField.leftFormField.keyboardType;
        cell.textFieldGender.keyboardType = inputVal;
        
        //Keyboard return key type
        NSInteger returnVal = compositeField.leftFormField.returnType;
        cell.textFieldGender.returnKeyType = returnVal;
        
        
        //User Interaction disable , because it view part
        cell.textFieldGender.userInteractionEnabled = NO;
        
        
        if (compositeField.leftFormField.isSecured) {
            cell.textFieldGender.secureTextEntry = YES;
        }
        
        //prefill if current input is having value
        cell.textFieldGender.text = compositeField.leftFormField.value;
        
        
        //>>>>Right Input
        compositeField.rightFormField.input = cell.textFieldBirthday;
        
        cell.textFieldBirthday.placeholder = compositeField.rightFormField.placeHolder;
        
        //Keyboard Type
        inputVal = compositeField.rightFormField.keyboardType;
        cell.textFieldBirthday.keyboardType = inputVal;
        
        //Keyboard return key type
        returnVal = compositeField.rightFormField.returnType;
        cell.textFieldBirthday.returnKeyType = returnVal;
        
        
        //User Interaction disable , because it view part
        cell.textFieldBirthday.userInteractionEnabled = NO;
        
        
        if (compositeField.rightFormField.isSecured) {
            cell.textFieldBirthday.secureTextEntry = YES;
        }
        
        //prefill if current input is having value
        cell.textFieldBirthday.text = compositeField.rightFormField.value;
        
        
        //Assigning txtInput Cell row no as tag
        cell.textFieldGender.tag = indexPath.row;
        cell.textFieldBirthday.tag = indexPath.row;
        
        return cell;
    }
    return nil;
}


- (void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [self.view endEditing:YES];
}

#pragma mark - ScrollView Methods

-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    if (scrollView.contentOffset.y<0) {
        tableViewTopBackgroundView.hidden = NO;
        float height =topViewHeightBase*SCREEN_HEIGHT+(-1*scrollView.contentOffset.y);
        [cnsttableViewTopBackgroundViewHeight setConstant:height];
    }else{
        tableViewTopBackgroundView.hidden = YES;
        [cnsttableViewTopBackgroundViewHeight setConstant:topViewHeightBase*SCREEN_HEIGHT];
    }
}

-(BOOL)scrollViewShouldScrollToTop:(UIScrollView *)scrollView{
    return NO;
}

@end
