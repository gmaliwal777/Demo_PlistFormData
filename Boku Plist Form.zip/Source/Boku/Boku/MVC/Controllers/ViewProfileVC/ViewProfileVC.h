//
//  ViewProfileVC.h
//  Boku
//
//  Created by Ghanshyam on 8/6/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import <UIKit/UIKit.h>

@class BusinessAccount;
@class Profile;

@interface ViewProfileVC : UIViewController<UITableViewDataSource,UITableViewDelegate,UIScrollViewDelegate>{
    /// Reference to add business account table view form
    IBOutlet UITableView *tableViewForm;
    
    /// Reference to table view top view
    IBOutlet    UIView  *tableViewTopView;
    
    /// Reference to Profile Info Tab
    IBOutlet    UIButton    *btnProfileInfo;
    
    /// Reference to Business Info Tab
    IBOutlet    UIButton    *btnBusinessInfo;
    
    /// Reference to tableViewTopBackgroundView
    IBOutlet    UIView      *tableViewTopBackgroundView;
    
    //// Reference to cnsttableViewTopBackgroundViewHeight
    IBOutlet    NSLayoutConstraint      *cnsttableViewTopBackgroundViewHeight;
    
    
    /**
     *  business account input model , used as per KVC norms
     */
    BusinessAccount *businessAccount;
    
    
    /**
     *  profile account input model , used as per KVC norms
     */
    Profile *profile;
    
    
    /**
     *  array of profile input keys ,only those input fields which will be rendered in table View for profile info
     */
    NSMutableArray *arrProfileInputKeys;
    
    
    /**
     *  array of Business input keys ,only those input fields which will be rendered in table View for business info
     */
    NSMutableArray *arrBusinessInputKeys;
    
    
    /**
     *  DispatchIdentifier to execute code once in current context
     */
    dispatch_once_t     dispatchCodeOnce;
    
}

@end
