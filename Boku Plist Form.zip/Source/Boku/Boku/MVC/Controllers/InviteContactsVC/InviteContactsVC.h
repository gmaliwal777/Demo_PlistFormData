//
//  InviteContactsVC.h
//  Boku
//
//  Created by Ashish Sharma on 03/08/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InviteContactsVC : UIViewController<UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate> {
    
    /// Reference to country list table view container
    IBOutlet __block UITableView *tableViewContacts;
    
    /// Reference to search bar textfield
    IBOutlet    UITextField     *textFieldSearch;

    /// Search Field height constraint reference
    IBOutlet NSLayoutConstraint *heightConstraintSearchFieldView;
    
    
    
    /// Reference to button that cause all contact selection
    IBOutlet    UIButton    *btnSelectAll;
    
    
    /// Reference to label that show total selection count
    IBOutlet    UILabel     *lblSelection;
    
    
    
    UIButton *buttonInvite;
    
    
    /**
     *  Dispatch identifier to execute specific code once in current context.
     */
    dispatch_once_t     dispatchCodeOnce;
    
    
    
}


/**
 *  Weak reference to mutable persons container , it can be updated . dont update it to nil if you do this then shared Contact array container will be freed-up.
 */
@property (nonatomic,weak)  NSMutableArray  *arrMutalbePersons;


@end
