//
//  InviteContactsVC.m
//  Boku
//
//  Created by Ashish Sharma on 03/08/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import "InviteContactsVC.h"
#import "ContactCell.h"
#import "Person.h"


@interface InviteContactsVC ()

@end

@implementation InviteContactsVC

#pragma mark - Super Class Methods

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self setupNavigationItems];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    /**
     *  PUT code which is to be executed once in current context .
     */
    dispatch_once(&dispatchCodeOnce, ^{
        
        //Having shared contacts weak reference
        NSMutableArray *arrPersons;
        [[Contacts sharedInstance] sharedContactsWeakReference:&arrPersons];
        self.arrMutalbePersons = arrPersons;
        [tableViewContacts reloadData];
        
        //Assigning handler to Singleton Contacts class , so it can be used to decide whent to start implementing logic basis on Contacts
        [[Contacts sharedInstance] setAdderssBookHandler:^{
            [tableViewContacts reloadData];
        }];
        
        
        [self updateUI];
    });
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];

}

-(void)dealloc{
    NSLog(@"invite code dealloc is here");
    
}


#pragma mark - Instance Methods

/**
 *  Used to update Invite Code UI basis on Person Selection
 */
-(void)updateUI{
    NSPredicate *selectionPredicate  =[NSPredicate predicateWithFormat:@"SELF.isSelected == %@",[NSNumber numberWithBool:YES]];
    NSArray *arrSelectedPersons = [_arrMutalbePersons filteredArrayUsingPredicate:selectionPredicate];
    
    buttonInvite.selected = arrSelectedPersons.count;
    
    lblSelection.text = [NSString stringWithFormat:@"%@ Selected",(arrSelectedPersons.count?[NSString stringWithFormat:@"%ld",arrSelectedPersons.count]:@"#")];
}


/**
 *  Used to select all contacts
 */
-(IBAction)selectAllContacts:(UIButton *)btnSender{
    
    btnSender.selected = !btnSender.selected;
    
    [_arrMutalbePersons makeObjectsPerformSelector:NSSelectorFromString(@"setSelectionValue:") withObject:[NSNumber numberWithBool:btnSender.selected]];
    
    [self updateUI];
    
    [tableViewContacts reloadData];
}


/**
 *  used to customize navigation bar items
 */
- (void)setupNavigationItems {
    
    [self setTitle:@"Invite via SMS"];
    
    UIButton *crossButton = [[UIButton alloc] initWithFrame:CGRectMake(0.f, 0.f, 50.f, 44.f)];
    [crossButton setImage:[UIImage imageNamed:@"crossButton"] forState:UIControlStateNormal];
    [crossButton addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];
    
    
    UIBarButtonItem *barButtonLeft = [[UIBarButtonItem alloc] initWithCustomView:crossButton];
    
    UIBarButtonItem *negativeSpacerLeft = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    negativeSpacerLeft.width = -16.f;
    
    [self.navigationItem setLeftBarButtonItems:[NSArray arrayWithObjects:negativeSpacerLeft,barButtonLeft,nil]];
    
    buttonInvite = [[UIButton alloc] initWithFrame:CGRectMake(40.f, 0.f, 40.f, 44.f)];
    [buttonInvite setImage:[UIImage imageNamed:@"addContact"] forState:UIControlStateNormal];
    [buttonInvite setImage:[UIImage imageNamed:@"addContactActive"] forState:UIControlStateSelected];
    
    
    UIButton *buttonSearch = [[UIButton alloc] initWithFrame:CGRectMake(0.f, 0.f, 40.f, 44.f)];
    [buttonSearch setImage:[UIImage imageNamed:@"search"] forState:UIControlStateNormal];
    [buttonSearch addTarget:self action:@selector(buttonSearchTap) forControlEvents:UIControlEventTouchUpInside];
    
    UIView *viewRightButtons = [[UIView alloc] initWithFrame:CGRectMake(0.f, 0.f, 80.f, 44.f)];
    [viewRightButtons setBackgroundColor:[UIColor clearColor]];
    
    [viewRightButtons addSubview:buttonSearch];
    [viewRightButtons addSubview:buttonInvite];
    
    UIBarButtonItem *barButtonRight = [[UIBarButtonItem alloc] initWithCustomView:viewRightButtons];
    
    UIBarButtonItem *negativeSpacerRight = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    negativeSpacerRight.width = -16.f;
    
    [self.navigationItem setRightBarButtonItems:[NSArray arrayWithObjects:negativeSpacerRight,barButtonRight, nil]];
}


-(void)backAction{
    
    //Making address book handler nil
    [[Contacts sharedInstance] setAdderssBookHandler:nil];
    
    [self.navigationController popViewControllerAnimated:YES];
}


/**
 *  Used to hide and show search bar
 */
- (void)buttonSearchTap {
    
    float height = 0.f;
    
    if (heightConstraintSearchFieldView.constant == 0.f) {

        height = SCREEN_WIDTH*(34.f/320.f);
        
        textFieldSearch.text = @"";
    }else{
        //Here search bar is no longer visible so we make all Contacts as filtered
        [_arrMutalbePersons makeObjectsPerformSelector:NSSelectorFromString(@"setFilterValue:") withObject:[NSNumber numberWithBool:YES]];
        [tableViewContacts reloadData];
        textFieldSearch.text = @"";
        [textFieldSearch resignFirstResponder];
    }
    
    [UIView animateWithDuration:0.4f
                     animations:^{
                         heightConstraintSearchFieldView.constant = height;
                         [self.view layoutIfNeeded];
                     }];
}


#pragma mark - UITableView Datasource and Delegate Methods


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    NSPredicate *fiterationPredicate = [NSPredicate predicateWithFormat:@"SELF.isFiltered == %@",[NSNumber numberWithBool:YES]];
    NSLog(@"count is %ld",_arrMutalbePersons.count);
    return [_arrMutalbePersons filteredArrayUsingPredicate:fiterationPredicate].count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return SCREEN_WIDTH*ROW_HEIGHT_MULTIPLIER;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *cellIdentifierInputFieldCell = @"CountryCell";
    
    ContactCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifierInputFieldCell];
    
    if (cell == nil) {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"ContactCell" owner:self options:nil] lastObject];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    
    NSPredicate *fiterationPredicate = [NSPredicate predicateWithFormat:@"SELF.isFiltered == %@",[NSNumber numberWithBool:YES]];
    NSArray *arrVisibleContacts = [_arrMutalbePersons filteredArrayUsingPredicate:fiterationPredicate];
    
    Person *person = [arrVisibleContacts objectAtIndex:indexPath.row];
    cell.labelUserName.text = person.displayName;
    
    cell.labelContactNo.text = person.bokuPhoneNo;
    
    
    cell.buttonTickMark.selected = person.isSelected;
    
    
    if (person.photo) {
        cell.imageViewUserProfile.image = person.photo;
    }
    
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSPredicate *fiterationPredicate = [NSPredicate predicateWithFormat:@"SELF.isFiltered == %@",[NSNumber numberWithBool:YES]];
    NSArray *arrVisibleContacts = [_arrMutalbePersons filteredArrayUsingPredicate:fiterationPredicate];
    
    Person *person = [arrVisibleContacts objectAtIndex:indexPath.row];
    
    person.isSelected = !person.isSelected;
    
    [self updateUI];
    
    [tableViewContacts reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
    
}



#pragma mark - UITextField Delegate
-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
    NSString *searchText = @"";
    if (string.length == 0) {
        //User is removing
        NSRange subrange;
        subrange = NSMakeRange(0, range.location);
        searchText = [textField.text substringWithRange:subrange];
    }else{
        //User is giving input in search bar
        searchText = [textField.text stringByAppendingString:string];
    }
    
    if (searchText.length>0) {
        //Filtering Persons container
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF.firstSearch CONTAINS[cd] %@ || SELF.secondSearch CONTAINS[cd] %@ ||SELF.bokuPhoneNo CONTAINS[cd] %@",searchText,searchText,searchText];
        NSArray *arrfilteredContacts = [_arrMutalbePersons filteredArrayUsingPredicate:predicate];
        //making Persons isFiltered to YES , these are those Persons which are in search criteria
        [arrfilteredContacts makeObjectsPerformSelector:NSSelectorFromString(@"setFilterValue:") withObject:[NSNumber numberWithBool:YES]];
        
        
        NSPredicate *notFilter = [NSCompoundPredicate notPredicateWithSubpredicate:predicate];
        NSArray *arrNonFilteredCountries = [_arrMutalbePersons filteredArrayUsingPredicate:notFilter];
        //making Country isFiltered to NO , these are those countries which are not in search criteria
        [arrNonFilteredCountries makeObjectsPerformSelector:NSSelectorFromString(@"setFilterValue:") withObject:[NSNumber numberWithBool:NO]];
        
    }else if (searchText.length==0){
        
        //Here we don't have any input in search bar so we make all countries as filtered
        [_arrMutalbePersons makeObjectsPerformSelector:NSSelectorFromString(@"setFilterValue:") withObject:[NSNumber numberWithBool:YES]];
    }
    
    //Reloading country list again
    [tableViewContacts reloadData];
    
    return YES;
}


@end

