//
//  AddBusinessAccountVC.m
//  Boku
//
//  Created by Ashish Sharma on 01/08/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import "AddBusinessAccountVC.h"
#import "BusinessAccount.h"
#import "BKFormField.h"
#import "InputFieldCell.h"
#import "AlertView.h"



@interface AddBusinessAccountVC ()

/**
 *  IBAction assign to done button
 *
 *  @param sender instance of caller
 */
- (IBAction)buttonDoneTap:(id)sender;

/**
 *  IBAction assign to skip button
 *
 *  @param sender instance of caller
 */
- (IBAction)buttonSkipTap:(id)sender;

@end

@implementation AddBusinessAccountVC

#pragma mark - Super Class Methods

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    arrInputKeys = [[NSMutableArray alloc] init];
    businessAccount = [[BusinessAccount alloc] init];
    
    [self setUpView];
    
    [self setUpBusinessAccountForm];
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    //Keyboardframe change notification
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardChangeFrameHandler:) name:UIKeyboardWillChangeFrameNotification object:nil];
    
    //Keyboard hide notification
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardHide:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    arrInputKeys = nil;
    
    businessAccount = nil;
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark - IBActions

- (IBAction)buttonDoneTap:(id)sender {
    [self.view endEditing:YES];
    
    if ([self validateUserInputs]) {
        //Validation get success , put code to move on next context
        
    }
}

- (IBAction)buttonSkipTap:(id)sender {
    
}

#pragma mark - Instance Methods

/**
 *  Used to make Current Context UI non user interacted
 */
-(void)makeUINonUserInteracted{
    [self.view endEditing:YES];
    
    NSLog(@"makeUINonUserInteracted");
}

/**
 *  Used to validate User input for OTP
 */
-(BOOL)validateUserInputs{
    NSError *error;
    int counter;
    for (counter=0; counter<arrInputKeys.count;counter++) {
        NSString *fieldKey = [arrInputKeys objectAtIndex:counter];
        
        id input = [businessAccount valueForKey:fieldKey];
        if ([input isKindOfClass:[BKFormField class]]) {
            
            BKFormField *formField = (BKFormField *)input;
            NSString *fieldValue = formField.value;
            
            [businessAccount validateValue:&fieldValue forKey:fieldKey error:&error];
        }
        
        if (error) {
            break;
        }
    }
    
    if (error) {
        //Validation failed at validating input at indexPath
        
        NSMutableArray *arrActions = [[NSMutableArray alloc] init];
        //Ok Button
        NSDictionary *dictTab = [[NSDictionary alloc] initWithObjectsAndKeys:@"OK",@"title",^{
            
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:counter inSection:0];
            [tableViewForm scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
            
            UITableViewCell* cell = [tableViewForm cellForRowAtIndexPath:indexPath];
            if (cell && [cell isKindOfClass:[InputFieldCell class]]) {
                InputFieldCell *inputCell = (InputFieldCell *)cell;
                [inputCell.textField becomeFirstResponder];
            }
            
        },@"action", nil];
        [arrActions addObject:dictTab];
        
        alert = [[AlertView alloc] init];
        [alert showAlertView:[error.userInfo objectForKey:NSLocalizedDescriptionKey] arrActions:arrActions];
        
        return NO;
    }else{
        return YES;
    }
}

/**
 *  Used to setup defualt ui configuration
 */
- (void)setUpView {
    
    [self setTitle:@"Set up a Business Account"];
    
    [CommonFunctions addBackButtonInNavigationItem:self.navigationItem forNavigationController:self.navigationController withTarget:nil andSelector:nil];
    
    //TapGesture on TableView so , on tap keyboard can be made down
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(makeUINonUserInteracted)];
    [tableViewForm addGestureRecognizer:tapGesture];
    tapGesture.cancelsTouchesInView = NO;
}

/**
 *  Used to set up login form context
 */
- (void)setUpBusinessAccountForm {
    
    NSArray *arrInputs = [CommonFunctions convertInputsWithResource:@"BusinessAccount" toModelClass:[BusinessAccount class]];
    
    for (int counter = 0;counter<arrInputs.count;counter++) {
        id input = [arrInputs objectAtIndex:counter];
        if ([input isKindOfClass:[BKFormField class]]) {
            //input is of BKFormField type
            BKFormField *singleField = (BKFormField *)input;
            [businessAccount setValue:singleField forKey:singleField.key];
            [arrInputKeys addObject:singleField.key];
        }
    }
}

/**
 *  Used to update User input into relevant Input Model
 *
 *  @param txtInput : current input being editing
 */
- (void)updateUserInput:(UITextField *)txtInput {
    
    id input = [businessAccount valueForKey:[arrInputKeys objectAtIndex:txtInput.tag]];
    if ([input isKindOfClass:[BKFormField class]]) {
        BKFormField *inputField = (BKFormField *)input;
        inputField.value = txtInput.text;
    }
}

#pragma mark - Keyboard Notification


/**
 *  KeyBoardFrameChangeHanlder Notification handler, called when ever keyboard sizes changed
 *
 *  @param notification : consist notification detail
 */
- (void)keyboardChangeFrameHandler:(NSNotification *)notification {
    NSDictionary* info = [notification userInfo];
    
    if ([info objectForKey:@"UIKeyboardAnimationDurationUserInfoKey"]) {
        keyboardAnimationTime = [notification.userInfo[UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    }else{
        keyboardAnimationTime = 0.25;
    }
    
    NSValue* aValue = [info objectForKey:UIKeyboardFrameEndUserInfoKey ];
    CGSize keyboardSize = [aValue CGRectValue].size;
    NSMutableDictionary *dictMetaData = [NSMutableDictionary dictionary];
    [dictMetaData setObject:@"UnKnownKeyBoard" forKey:@"type"];
    [dictMetaData setObject:[NSNumber numberWithInt:keyboardSize.height] forKey:@"size"];
    [self keyboardChangeWithMetaData:dictMetaData];
}

/**
 *  KeyboardHide Notification handler , called when ever keyboard gets down or hide
 *
 *  @param notification : consist notification detail
 */
- (void)keyboardHide:(NSNotification *)notification {
    //we have to set constraints as below
    [UIView animateWithDuration:keyboardAnimationTime animations:^{
        [cnstTableViewBottom setConstant:0.0f];
        [tableViewForm layoutIfNeeded];
    }];
}

/**
 *  Selector called to respond KeyboardFrameChange Notification
 *
 *  @param dictMetaData : Consist detail about notification
 */
- (void)keyboardChangeWithMetaData:(NSDictionary *)dictMetaData {
    NSLog(@"meta data is %@",dictMetaData);
    keyBoardHeight = [[dictMetaData valueForKey:@"size"] floatValue];
    
    //[self.bottomChatViewConstraint setConstant:keyBoardHeight];
    [UIView animateWithDuration:keyboardAnimationTime animations:^{
        [cnstTableViewBottom setConstant:keyBoardHeight];
        [tableViewForm layoutIfNeeded];
    }];
}

#pragma mark - UITableView Datasource and Delegate Methods

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return arrInputKeys.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return SCREEN_WIDTH*ROW_HEIGHT_MULTIPLIER;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    id input = [businessAccount valueForKey:[arrInputKeys objectAtIndex:indexPath.row]];
    
    if ([input isKindOfClass:[BKFormField class]]) {
        
        BKFormField *inputField = (BKFormField *)input;
        
        static NSString *cellIdentifierInputFieldCell = @"InputFieldCell";
        
        
        InputFieldCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifierInputFieldCell];
        
        if (cell == nil) {
            cell = [[[NSBundle mainBundle] loadNibNamed:@"InputFieldCell" owner:self options:nil] lastObject];
            cell.textField.delegate = self;
        }
        
        //Assigning txtInput view to model for further referencing
        inputField.input = cell.textField;
        
        cell.textField.placeholder = inputField.placeHolder;
        
        //Keyboard Type
        NSInteger inputVal = inputField.keyboardType;
        cell.textField.keyboardType = inputVal;
        
        //Keyboard return key type
        NSInteger returnVal = inputField.returnType;
        cell.textField.returnKeyType = returnVal;
        
        
        //User Interaction
        cell.textField.userInteractionEnabled = inputField.userInteraction;
        
        
        if (inputField.isSecured) {
            cell.textField.secureTextEntry = YES;
        }
        
        //prefill if current input is having value
        cell.textField.text = inputField.value;
        
        
        //Assigning txtInput Cell row no as tag
        cell.textField.tag = indexPath.row;
        
        
        return cell;
    }
    
    return nil;
}

- (void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [self.view endEditing:YES];
}

#pragma mark - UITextField Delegate
-(void)textFieldDidBeginEditing:(UITextField *)textField{
    if (textField == businessAccount.hashTags.input &&
        textField.text.length==0) {
        
        //Business Account is having focus , so we put initial #
        textField.text = @"#";
    }
}

-(void)textFieldDidEndEditing:(UITextField *)textField{
    if (textField == businessAccount.hashTags.input) {
        
        if ([textField.text isEqualToString:@"#"]) {
            //Profile Hash Tag is goint to loss focus , so we remove initial #
            textField.text = @"";
        }
        
        NSString *completeText = textField.text;
        
        if (completeText.length>=2) {
            NSString *lastTwoChar = [completeText substringFromIndex:completeText.length-2];
            if ([lastTwoChar isEqualToString:@" #"]) {
                //having  space just after # , don't allow it
                NSMakeRange(completeText.length-2, 1);
                NSString *correctHashTags = [completeText substringWithRange:NSMakeRange(0, completeText.length-2)];
                textField.text = correctHashTags;
            }
        }
    }
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {

    
    NSString *completeText = textField.text;
    if (textField == businessAccount.hashTags.input
        && ((string.length==0 && completeText.length==1) || string.length>1)) {
        //At least first # not to be removed by user or pasting of char of more than one length is restricted
        return NO;
    }
    
    
    if (string.length > 0) {
        //User is giving input
        completeText = [completeText stringByAppendingString:string];
        
    }else{
        //User is removing input
        NSRange subRange = NSMakeRange(0, range.location);
        completeText = [completeText substringWithRange:subRange];
    }
    
    
    if (textField == businessAccount.hashTags.input) {
        
        if (string.length>0 && [string isEqualToString:@"#"]) {
            //Explicit user # input is restricted
            return NO;
        }
        
        if (completeText.length>=2) {
            NSString *lastTwoChar = [completeText substringFromIndex:completeText.length-2];
            if ([lastTwoChar isEqualToString:@"# "] || [lastTwoChar isEqualToString:@"  "]) {
                //having  space just after # , don't allow it
                return NO;
            }
        }
        
        if (completeText.length>0 && string.length>0) {
            NSString *lastChar = [completeText substringFromIndex:completeText.length-1];
            if ([lastChar isEqualToString:@" "]) {
                //having  space again so append # also
                completeText = [completeText stringByAppendingString:@"#"];
            }else{
                if (completeText.length>=2 && string.length>0) {
                    NSString *secondLastChar = [completeText substringWithRange:NSMakeRange(completeText.length-2, 1)];
                    if ([secondLastChar isEqualToString:@" "]) {
                        //We have character and second last character is space and no space after space .
                        NSString *lastChar = [completeText substringFromIndex:completeText.length-1];
                        NSString *remaingChar = [completeText substringToIndex:completeText.length-1];
                        completeText = [remaingChar stringByAppendingString:@"#"];
                        completeText = [completeText stringByAppendingString:lastChar];
                    }
                    NSLog(@"secondLastChar == %@",secondLastChar);
                }
            }
        }
        
        
        
        
    }
    
    
    textField.text = completeText;
    
    
    //Updating Input Model for updated user input
    [self updateUserInput:textField];
    
    return NO;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    NSInteger returnTypeVal = textField.returnKeyType;
    BKReturnKeyType returnType = returnTypeVal;
    if (returnType == BKReturnKeyDone) {
        [textField resignFirstResponder];
    }else if(returnType == BKReturnKeyNext){
        //Return type is next we will move to next input
        
        int currentRow = (int)textField.tag;
        if (currentRow+1<arrInputKeys.count) {
            //WE have more inputs to be made as become first responder
            NSIndexPath *nextIndexPath = [NSIndexPath indexPathForRow:currentRow+1 inSection:0];
            
            UITableViewCell *cell = [tableViewForm cellForRowAtIndexPath:nextIndexPath];
            
            if (cell && [cell isKindOfClass:[InputFieldCell class]]) {
                InputFieldCell *fieldCell = (InputFieldCell *)cell;
                [fieldCell.textField becomeFirstResponder];
            }
        }else{
            [textField resignFirstResponder];
        }
    }
    
    return YES;
}

@end
