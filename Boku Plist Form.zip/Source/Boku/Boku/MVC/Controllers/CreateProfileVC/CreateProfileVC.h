//
//  CreateProfileVC.h
//  Boku
//
//  Created by Ashish Sharma on 01/08/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Profile;
@class AlertView;
@class Options;
@class DropDownView;
@class DatePickerView;
@class LocationService;

@interface CreateProfileVC : UIViewController<UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate>{
    
    
    /// Reference to tableViewTopBackgroundView
    IBOutlet    UIView      *tableViewTopBackgroundView;
    
    //// Reference to cnsttableViewTopBackgroundViewHeight
    IBOutlet    NSLayoutConstraint      *cnsttableViewTopBackgroundViewHeight;
    
    
    /// Reference to add business account table view form
    IBOutlet UITableView *tableViewForm;
    
    
    /// Reference to tableview bottom constraints
    IBOutlet NSLayoutConstraint *cnstTableViewBottom;
    
    /**
     *  profile account input model , used as per KVC norms
     */
    Profile *profile;
    
    /**
     *  array of input keys ,only those input fields which will be rendered in table View
     */
    NSMutableArray *arrInputKeys;
    
    /**
     * keep keyboard animation time frame
     */
    NSTimeInterval keyboardAnimationTime;
    
    /**
     *  keyboard height , when keyboard appears on screen
     */
    float keyBoardHeight;
    
    
    /**
     *  AlertView to give alert to User
     */
    AlertView       *alert;
    
    /**
     *  Reference to already selected Gender option
     */
    Options         *genderOption;
    
    /**
     *  Selected row value to be moved to that row in dropdown
     */
    NSInteger                   selectedRow;
    
    
    /**
     *  Location service delegator
     */
    LocationService         *locService;
    
    
    /**
     *  Dispatch identifier to execute code once in current context
     */
    dispatch_once_t         dispatchCodeOnce;
}


/**
 *  Reference to drop down menu
 */
@property(nonatomic,strong)           DropDownView              *dropDownView;


/**
 *  Reference to DatePickerView
 */
@property (nonatomic,strong)          DatePickerView            *datePickerView;




@end
