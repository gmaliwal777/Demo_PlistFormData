//
//  CreateProfileVC.m
//  Boku
//
//  Created by Ashish Sharma on 01/08/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import "CreateProfileVC.h"
#import "Profile.h"
#import "BKFormField.h"
#import "BKCompositeFormField.h"
#import "InputFieldCell.h"
#import "BioCell.h"
#import "AlertView.h"
#import "Options.h"
#import "DropDownView.h"
#import "DatePickerView.h"
#import <CoreLocation/CoreLocation.h>
#import "LocationService.h"


@interface CreateProfileVC ()<DropDownDelegate,DateDelegate,LocationServiceDelegate>

@end

@implementation CreateProfileVC

#define topViewHeightBase   0.33450

#pragma mark - Super Class Methods

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    arrInputKeys = [[NSMutableArray alloc] init];
    profile = [[Profile alloc] init];
    keyboardAnimationTime = 0.25;
    
    
    [self setUpProfileForm];
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self setUpView];
    
    
    //Keyboardframe change notification
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardChangeFrameHandler:) name:UIKeyboardWillChangeFrameNotification object:nil];
    
    //Keyboard hide notification
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardHide:) name:UIKeyboardWillHideNotification object:nil];
    
    //Reverse Geo Address Notification
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reverseGeoAddress:) name:BK_REVERSE_GEOCODE_ADDRESS_NOTIFICATION object:nil];
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    
    /**
     *  PUT code which is to be executed once in current context .
     */
    dispatch_once(&dispatchCodeOnce, ^{
        //Call to location manager
        [self configureLocationService];
    });
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)dealloc{
    
    arrInputKeys = nil;
    
    profile = nil;
    
    self.dropDownView = nil;
    
    self.datePickerView = nil;
}


#pragma mark - Notification Handler

/**
 *  GeoAction Notification observer to handler reverse geocoded address
 *
 *  @param notification : Notification with UserInfo
 */
-(void)reverseGeoAddress:(NSNotification *)notification{
    NSDictionary *dictGeoLocation = [notification userInfo];
    NSLog(@"address is in signup %@",dictGeoLocation);
    
    if ([dictGeoLocation objectForKey:@"country"]) {
        BKFormField *formField = profile.location;
        formField.value = [dictGeoLocation objectForKey:@"country"];
        UITextField *txtLocation = (UITextField *)formField.input;
        
        txtLocation.text = [dictGeoLocation objectForKey:@"country"];
    }
}

/**
 *  KeyBoardFrameChangeHanlder Notification handler, called when ever keyboard sizes changed
 *
 *  @param notification : consist notification detail
 */
- (void)keyboardChangeFrameHandler:(NSNotification *)notification {
    NSDictionary* info = [notification userInfo];
    
    if ([info objectForKey:@"UIKeyboardAnimationDurationUserInfoKey"]) {
        keyboardAnimationTime = [notification.userInfo[UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    }else{
        keyboardAnimationTime = 0.25;
    }
    
    NSValue* aValue = [info objectForKey:UIKeyboardFrameEndUserInfoKey ];
    CGSize keyboardSize = [aValue CGRectValue].size;
    NSMutableDictionary *dictMetaData = [NSMutableDictionary dictionary];
    [dictMetaData setObject:@"UnKnownKeyBoard" forKey:@"type"];
    [dictMetaData setObject:[NSNumber numberWithInt:keyboardSize.height] forKey:@"size"];
    [self keyboardChangeWithMetaData:dictMetaData];
}

/**
 *  KeyboardHide Notification handler , called when ever keyboard gets down or hide
 *
 *  @param notification : consist notification detail
 */
- (void)keyboardHide:(NSNotification *)notification {
    //we have to set constraints as below
    NSLog(@"key board hide %@",_dropDownView);
    [UIView animateWithDuration:keyboardAnimationTime animations:^{
        [cnstTableViewBottom setConstant:0.0f];
        [tableViewForm layoutIfNeeded];
    }];
}

/**
 *  Selector called to respond KeyboardFrameChange Notification
 *
 *  @param dictMetaData : Consist detail about notification
 */
- (void)keyboardChangeWithMetaData:(NSDictionary *)dictMetaData {
    NSLog(@"meta data is %@",dictMetaData);
    keyBoardHeight = [[dictMetaData valueForKey:@"size"] floatValue];
    
    //[self.bottomChatViewConstraint setConstant:keyBoardHeight];
    [UIView animateWithDuration:keyboardAnimationTime animations:^{
        [cnstTableViewBottom setConstant:keyBoardHeight];
        [tableViewForm layoutIfNeeded];
    }];
}


#pragma mark - LocationServcie Delegate
-(void)locationServiceFailed{
    [locService stopLocationManager];
    locService = nil;
    
    [self locationWithLocale];
}

-(void)locationServiceNotAuthorized{
    [locService stopLocationManager];
    locService = nil;
    
    [self locationWithLocale];
}

-(void)locationServiceDoneWithLatitude:(float)latitude longitude:(float)longitude{
    locService = nil;
}


#pragma mark - Instance Methods

/**
 *  Used to setup defualt ui configuration
 */
- (void)setUpView {
    
    [self.navigationController setNavigationBarHidden:YES];
    
    //TableHeaderView height
    CGRect rectTableHeaderView = tableViewForm.tableHeaderView.frame;
    rectTableHeaderView.size.height = SCREEN_WIDTH*HEADER_VIEW_HEIGHT_MULTIPLIER;
    tableViewForm.tableHeaderView.frame = rectTableHeaderView;
    
    //TapGesture on TableView so , on tap keyboard can be made down
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(makeUINonUserInteracted)];
    [tableViewForm addGestureRecognizer:tapGesture];
    tapGesture.cancelsTouchesInView = NO;
}



/**
 *  Used to set up profile form context
 */
- (void)setUpProfileForm {
    
    NSArray *arrInputs = [CommonFunctions convertInputsWithResource:@"Profile" toModelClass:[Profile class]];
    
    for (int counter = 0;counter<arrInputs.count;counter++) {
        id input = [arrInputs objectAtIndex:counter];
        if ([input isKindOfClass:[BKFormField class]]) {
            //input is of BKFormField type
            BKFormField *singleField = (BKFormField *)input;
            [profile setValue:singleField forKey:singleField.key];
            [arrInputKeys addObject:singleField.key];
        }else if ([input isKindOfClass:[BKCompositeFormField class]]){
            
            BKCompositeFormField *compositeField = (BKCompositeFormField *)input;
            
            [profile setValue:compositeField forKey:compositeField.key];
            
            //Adding input key in arrInputs , to have functioning later
            [arrInputKeys addObject:compositeField.key];
        }
    }
}

/**
 *  Used to update User input into relevant Input Model
 *
 *  @param txtInput : current input being editing
 */
- (void)updateUserInput:(UITextField *)txtInput {
    
    id input = [profile valueForKey:[arrInputKeys objectAtIndex:txtInput.tag]];
    if ([input isKindOfClass:[BKFormField class]]) {
        BKFormField *inputField = (BKFormField *)input;
        inputField.value = txtInput.text;
    }else if ([input isKindOfClass:[BKCompositeFormField class]]){
        BKCompositeFormField *compositeField = (BKCompositeFormField *)input;
        
        if (compositeField.leftFormField.input == txtInput) {
            compositeField.leftFormField.value = txtInput.text;
        }else if (compositeField.rightFormField.input == txtInput){
            compositeField.rightFormField.value = txtInput.text;
        }
    }
}


/**
 *  Used to prefill location with Device Locale
 */
-(void)locationWithLocale{
    NSLocale *locale = [NSLocale currentLocale];
    NSString *countryCode = [locale objectForKey: NSLocaleCountryCode];
    
    NSLocale *usLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
    
    NSString *country = [usLocale displayNameForKey: NSLocaleCountryCode value: countryCode];
    
    BKFormField *formField = profile.location;
    formField.value = country;
    UITextField *txtLocation = (UITextField *)formField.input;
    txtLocation.text = country;
}


-(void)configureLocationService{
    //Configuring Location Manager
    
    CLAuthorizationStatus authStatus = [CLLocationManager authorizationStatus];
    BOOL flag = NO;
    if (authStatus == kCLAuthorizationStatusAuthorizedWhenInUse) {
        flag = YES;
    }
    NSString *locationRequestToIOS = (NSString *)[CommonFunctions getUserDefaultValue:@"locationRequestToIOS"];
    if ([CLLocationManager locationServicesEnabled]) {
        if ( (![locationRequestToIOS isEqualToString:@"YES"] || flag)) {
            if (!locationRequestToIOS) {
                [CommonFunctions setUserDefault:@"locationRequestToIOS" value:@"YES"];
            }
            locService = [[LocationService alloc] initAndtoDoRevereGeocoding:YES];
            locService.delegate = self;
            [locService startLocationManager];
        }else{
            [self locationWithLocale];
        }
    }else{
        [self locationWithLocale];
    }
}


-(IBAction)createProfile{
    [self.view endEditing:YES];
    
    if ([self validateUserInputs]) {
        //validation get success here , put code to move on next context
        
    }
}

/**
 *  Used to fetch Gender list from resource and show that list in PickerView
 */
-(void)showGenderList{
    NSString *genderPlistPath = [[NSBundle mainBundle] pathForResource:@"Gender" ofType:@"plist"];
    
    //Consist raw inputs from resource plist
    NSArray* arrGender = [NSArray arrayWithContentsOfFile:genderPlistPath];
    
    NSMutableArray *arrOptions = [[NSMutableArray alloc] init];
    
    //selectedRow = 0;
    for (int counter =0; counter<arrGender.count; counter++) {
        NSDictionary *dictGender = [arrGender objectAtIndex:counter];
        
        Options *option = [[Options alloc] init];
        
        option.name = [dictGender objectForKey:@"name"];
        option.idVal = [dictGender objectForKey:@"code"];
        option.isSelected = NO;
        
        if (genderOption && [genderOption.idVal isEqualToString:[dictGender objectForKey:@"code"]]) {
            option.isSelected = YES;
            selectedRow = counter;
        }
        [arrOptions addObject:option];
    }
    [self showCustomOptionsView:profile.bio.leftFormField.input WithOptions:arrOptions];
}

/**
 *  Used to show drop down
 *
 *  @param caller     : instance which is triggering dropdown
 *  @param arrOptions : options array in dropdown
 */
-(void)showCustomOptionsView:(id)caller WithOptions:(NSArray *)arrOptions{
    
    if (!self.dropDownView) {
        CGRect frame = CGRectMake(0, SCREEN_HEIGHT, SCREEN_WIDTH, (DROPDOWN_HEIGHT_MULTIPLIER*SCREEN_WIDTH));
        self.dropDownView = [[DropDownView alloc] initWithFrame:frame color:[UIColor colorWithRed:17/255.0f green:117/255.0f blue:187/255.0f alpha:1]];
        self.dropDownView.delegate = self;
        [self.view addSubview:self.dropDownView];
    }
    
    if (caller == profile.bio.leftFormField.input) {
        _dropDownView.strTitle = @"Gender";
    }
    
    self.dropDownView.callingObj = caller;
    [_dropDownView setOptions:arrOptions];
    [_dropDownView.pickerView selectRow:selectedRow inComponent:0 animated:YES];
    
    if (!self.dropDownView.showing) {
        NSLog(@"going to show");
        [UIView animateWithDuration:0.3 animations:^{
            CGRect frame = self.dropDownView.frame;
            NSLog(@"options view frame is %@",NSStringFromCGRect(frame));
            frame.origin.y = SCREEN_HEIGHT - (DROPDOWN_HEIGHT_MULTIPLIER*SCREEN_WIDTH);
            self.dropDownView.frame = frame;
            
        } completion:^(BOOL finished) {
            self.dropDownView.showing = YES;
        }];
    }
}

/**
 *  Used to remove custom dropdown view
 */
-(void)removeCustomOptionsView{
    if (self.dropDownView) {
        [UIView animateWithDuration:0.3 animations:^{
            CGRect frame = _dropDownView.frame;
            frame.origin.y = SCREEN_HEIGHT;
            _dropDownView.frame = frame;
        } completion:^(BOOL finished) {
            [_dropDownView removeFromSuperview];
            self.dropDownView = nil;
        }];
    }
}

/**
 *  Used to show Date Picker View for Birthday selection
 *
 *  @param caller : caller which is causing date selection
 */
-(void)showDatePickerView:(id)caller{
    
    if (!self.datePickerView) {
        CGRect frame = CGRectMake(0, SCREEN_HEIGHT, SCREEN_WIDTH, (DROPDOWN_HEIGHT_MULTIPLIER*SCREEN_WIDTH));
        self.datePickerView = [[DatePickerView alloc] initWithFrame:frame];
        self.datePickerView.delegate = self;
        [self.view addSubview:self.datePickerView];
    }
    
    if (caller == profile.bio.rightFormField.input) {
        _datePickerView.strTitle = @"Birthday";
        
        //Default date selection in Date PickerView either current date &
        NSDate *selectedDate = [NSDate date];
        
        if (((NSString *)(profile.bio.rightFormField.value)).length>0) {
            NSDateFormatter*    dateFormatter = [[NSDateFormatter alloc] init];
            [dateFormatter setTimeZone:[NSTimeZone systemTimeZone]];
            [dateFormatter setDateFormat:@"MM/dd/yyyy"];
            
            selectedDate = [dateFormatter dateFromString:((NSString *)(profile.bio.rightFormField.value))];
        }
        
        [_datePickerView setUpDatePickerWithDate:selectedDate];
    }
    
    
    self.datePickerView.callingObj = caller;
    
    if (!self.datePickerView.showing) {
        NSLog(@"going to show");
        [UIView animateWithDuration:0.3 animations:^{
            CGRect frame = self.datePickerView.frame;
            NSLog(@"options view frame is %@",NSStringFromCGRect(frame));
            frame.origin.y = SCREEN_HEIGHT - (DROPDOWN_HEIGHT_MULTIPLIER*SCREEN_WIDTH);
            self.datePickerView.frame = frame;
            
        } completion:^(BOOL finished) {
            self.datePickerView.showing = YES;
        }];
    }
}


/**
 *  Used to remove Date Picker view
 */
-(void)removeDatePickerView{
    if (self.datePickerView) {
        [UIView animateWithDuration:0.3 animations:^{
            CGRect frame = _datePickerView.frame;
            frame.origin.y = SCREEN_HEIGHT;
            _datePickerView.frame = frame;
        } completion:^(BOOL finished) {
            [_datePickerView removeFromSuperview];
            self.datePickerView = nil;
        }];
    }
}

#pragma mark - DatePicker Delegate
-(void)dateCancelled:(id)referenceObj{
    NSLog(@"date cancelled");
    //Removing Date Picker View , if any existing
    [self removeDatePickerView];
    
}

-(void)dateDidSelect:(NSDate *)selectedDate referenceObj:(id)referenceObj{
    NSLog(@"date selected is %@",selectedDate);
    
    if (referenceObj == profile.bio.rightFormField.input) {
        //Gender input is here
        UITextField *textFieldBirthday = (UITextField *)profile.bio.rightFormField.input;
        
        NSDateFormatter*    dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"MM/dd/yyyy"];
        
        NSString *strDate = [dateFormatter stringFromDate:selectedDate];
        NSLog(@"selected date is %@",strDate);
        
        textFieldBirthday.text = strDate;
        
        [self updateUserInput:textFieldBirthday];
    }
    
    
    //Removing Date Picker View , if any existing
    [self removeDatePickerView];
}


#pragma mark - DropDown Delegate

-(void)dropDownCancelled:(id)referenceObj{
    [self removeCustomOptionsView];
}

-(void)dropDownDidSelect:(Options *)option referenceObj:(id)referenceObj{
    if (option) {
        if (referenceObj == profile.bio.leftFormField.input) {
            //Gender input is here
            UITextField *textFieldGender = (UITextField *)profile.bio.leftFormField.input;
            textFieldGender.text = option.name;
            
            [self updateUserInput:textFieldGender];
        }
        genderOption = option;
    }
    [self removeCustomOptionsView];
}


/**
 *  Used to make Current Context UI non user interacted
 */
-(void)makeUINonUserInteracted{
    //Removing Drop-Down , if any existing
    [self removeCustomOptionsView];
    
    //Removing Date Picker View , if any existing
    [self removeDatePickerView];
    
    
    [self.view endEditing:YES];
}

/**
 *  Used to validate User input for OTP
 */
-(BOOL)validateUserInputs{
    NSError *error;
    
    //We have this error , so we can show left input is wrong
    NSError *leftError;
    
    int counter;
    for (counter=0; counter<arrInputKeys.count;counter++) {
        NSString *fieldKey = [arrInputKeys objectAtIndex:counter];
        
        id input = [profile valueForKey:fieldKey];
        if ([input isKindOfClass:[BKFormField class]]) {
            
            BKFormField *formField = (BKFormField *)input;
            NSString *fieldValue = formField.value;
            
            [profile validateValue:&fieldValue forKey:fieldKey error:&error];
        }else if ([input isKindOfClass:[BKCompositeFormField class]]){
            
            BKCompositeFormField *compositeField = (BKCompositeFormField *)input;
            
            NSString *leftFieldKey = compositeField.leftFormField.key;
            NSString *leftFieldValue = compositeField.leftFormField.value;
            
            [profile validateValue:&leftFieldValue forKey:leftFieldKey error:&leftError];
            if (leftError) {
                break;
            }
            
            
            NSString *rightFieldKey = compositeField.rightFormField.key;
            NSString *rightFieldValue = compositeField.rightFormField.value;
            
            [profile validateValue:&rightFieldValue forKey:rightFieldKey error:&error];
            
        }
        
        if (error) {
            break;
        }
    }
    
    if (error || leftError) {
        //Validation failed at validating input at indexPath
        
        NSMutableArray *arrActions = [[NSMutableArray alloc] init];
        //Ok Button
        NSDictionary *dictTab = [[NSDictionary alloc] initWithObjectsAndKeys:@"OK",@"title",^{
            
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:counter inSection:0];
            [tableViewForm scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
            
            UITableViewCell* cell = [tableViewForm cellForRowAtIndexPath:indexPath];
            if (cell && [cell isKindOfClass:[InputFieldCell class]]) {
                InputFieldCell *inputCell = (InputFieldCell *)cell;
                [inputCell.textField becomeFirstResponder];
            }else if (cell && [cell isKindOfClass:[BioCell class]]){
                BioCell *bioCell = (BioCell *)cell;
                if (leftError) {
                    [bioCell.textFieldGender becomeFirstResponder];
                }else{
                    [bioCell.textFieldBirthday becomeFirstResponder];
                }
            }
            
        },@"action", nil];
        [arrActions addObject:dictTab];
        
        alert = [[AlertView alloc] init];
        [alert showAlertView:[(error.userInfo?error.userInfo:leftError.userInfo) objectForKey:NSLocalizedDescriptionKey] arrActions:arrActions];
        
        return NO;
    }else{
        return YES;
    }
}




#pragma mark - UITableView Datasource and Delegate Methods


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return arrInputKeys.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return SCREEN_WIDTH*ROW_HEIGHT_MULTIPLIER;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    id input = [profile valueForKey:[arrInputKeys objectAtIndex:indexPath.row]];
    
    if ([input isKindOfClass:[BKFormField class]]) {
        
        BKFormField *inputField = (BKFormField *)input;
        
        static NSString *cellIdentifierInputFieldCell = @"InputFieldCell";
        
        
        InputFieldCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifierInputFieldCell];
        
        if (cell == nil) {
            cell = [[[NSBundle mainBundle] loadNibNamed:@"InputFieldCell" owner:self options:nil] lastObject];
            cell.textField.delegate = self;
        }
        
        //Assigning txtInput view to model for further referencing
        inputField.input = cell.textField;
        
        cell.textField.placeholder = inputField.placeHolder;
        
        //Keyboard Type
        NSInteger inputVal = inputField.keyboardType;
        cell.textField.keyboardType = inputVal;
        
        //Keyboard return key type
        NSInteger returnVal = inputField.returnType;
        cell.textField.returnKeyType = returnVal;
        
        
        //User Interaction
        cell.textField.userInteractionEnabled = inputField.userInteraction;
        
        
        if (inputField.isSecured) {
            cell.textField.secureTextEntry = YES;
        }
        
        //prefill if current input is having value
        cell.textField.text = inputField.value;
        
        
        //Assigning txtInput Cell row no as tag
        cell.textField.tag = indexPath.row;
        
        
        return cell;
    }else if([input isKindOfClass:[BKCompositeFormField class]]){
        
        BKCompositeFormField *compositeField = (BKCompositeFormField *)input;
        
        static NSString *cellIdentifierBioCell = @"BioCell";
        BioCell *cell = (BioCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifierBioCell];

        if (!cell) {
            cell = [[[NSBundle mainBundle] loadNibNamed:@"BioCell" owner:self options:nil] lastObject];
            //cell.textFieldGender.rightViewMode = UITextFieldViewModeAlways;
            cell.textFieldGender.delegate = self;
            
            //cell.textFieldBirthday.rightViewMode = UITextFieldViewModeAlways;
            cell.textFieldBirthday.delegate = self;
        }
        
        //>>>>Left Input
        compositeField.leftFormField.input = cell.textFieldGender;
        
        cell.textFieldGender.placeholder = compositeField.leftFormField.placeHolder;
        
        //Keyboard Type
        NSInteger inputVal = compositeField.leftFormField.keyboardType;
        cell.textFieldGender.keyboardType = inputVal;
        
        //Keyboard return key type
        NSInteger returnVal = compositeField.leftFormField.returnType;
        cell.textFieldGender.returnKeyType = returnVal;
        
        
        //User Interaction
        cell.textFieldGender.userInteractionEnabled = compositeField.leftFormField.userInteraction;
        
        
        if (compositeField.leftFormField.isSecured) {
            cell.textFieldGender.secureTextEntry = YES;
        }
        
        //prefill if current input is having value
        cell.textFieldGender.text = compositeField.leftFormField.value;
        
        
        //>>>>Right Input
        compositeField.rightFormField.input = cell.textFieldBirthday;
        
        cell.textFieldBirthday.placeholder = compositeField.rightFormField.placeHolder;
        
        //Keyboard Type
        inputVal = compositeField.rightFormField.keyboardType;
        cell.textFieldBirthday.keyboardType = inputVal;
        
        //Keyboard return key type
        returnVal = compositeField.rightFormField.returnType;
        cell.textFieldBirthday.returnKeyType = returnVal;
        
        
        //User Interaction
        cell.textFieldBirthday.userInteractionEnabled = compositeField.rightFormField.userInteraction;
        
        
        if (compositeField.rightFormField.isSecured) {
            cell.textFieldBirthday.secureTextEntry = YES;
        }
        
        //prefill if current input is having value
        cell.textFieldBirthday.text = compositeField.rightFormField.value;
        
        
        //Assigning txtInput Cell row no as tag
        cell.textFieldGender.tag = indexPath.row;
        cell.textFieldBirthday.tag = indexPath.row;
        
        return cell;
        
    }
    
    return nil;
}

- (void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [self.view endEditing:YES];
}

#pragma mark - UITextField Delegate
-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    NSLog(@"should start");
    if (textField == profile.bio.leftFormField.input ) {
        //Gender input is triggered
        [self.view endEditing:YES];
        [self showGenderList];
        
        return NO;
    }else if (textField == profile.bio.rightFormField.input){
        [self.view endEditing:YES];
        [self showDatePickerView:textField];
        
        return NO;
    }
    return YES;
}

-(void)textFieldDidBeginEditing:(UITextField *)textField{
    //Removing Drop-Down , if any existing
    [self removeCustomOptionsView];
    
    //Removing Date Picker View , if any existing
    [self removeDatePickerView];
    
    NSLog(@"did begin editting");
    if (textField == profile.hash_tags.input &&
        textField.text.length==0) {
        
        //Profile Hash Tag is having focus , so we put initial #
        textField.text = @"#";
    }
}

-(void)textFieldDidEndEditing:(UITextField *)textField{
    if (textField == profile.hash_tags.input) {
        
        if ([textField.text isEqualToString:@"#"]) {
            //Profile Hash Tag is goint to loss focus , so we remove initial #
            textField.text = @"";
        }
        
        NSString *completeText = textField.text;
        
        if (completeText.length>=2) {
            NSString *lastTwoChar = [completeText substringFromIndex:completeText.length-2];
            if ([lastTwoChar isEqualToString:@" #"]) {
                //having  space just after # , don't allow it
                NSMakeRange(completeText.length-2, 1);
                NSString *correctHashTags = [completeText substringWithRange:NSMakeRange(0, completeText.length-2)];
                textField.text = correctHashTags;
            }
        }
    }
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    
    
    NSString *completeText = textField.text;
    if (textField == profile.hash_tags.input
        && ((string.length==0 && completeText.length==1) || string.length>1)) {
        //At least first # not to be removed by user or pasting of char of more than one length is restricted
        return NO;
    }
    
    
    if (string.length > 0) {
        //User is giving input
        completeText = [completeText stringByAppendingString:string];
        
    }else{
        //User is removing input
        NSRange subRange = NSMakeRange(0, range.location);
        completeText = [completeText substringWithRange:subRange];
    }
    
    
    if (textField == profile.hash_tags.input) {
        
        if (string.length>0 && [string isEqualToString:@"#"]) {
            //Explicit user # input is restricted
            return NO;
        }
        
        if (completeText.length>=2) {
            NSString *lastTwoChar = [completeText substringFromIndex:completeText.length-2];
            if ([lastTwoChar isEqualToString:@"# "] || [lastTwoChar isEqualToString:@"  "]) {
                //having  space just after # , don't allow it
                return NO;
            }
        }
        
        if (completeText.length>0 && string.length>0) {
            NSString *lastChar = [completeText substringFromIndex:completeText.length-1];
            if ([lastChar isEqualToString:@" "]) {
                //having  space again so append # also
                completeText = [completeText stringByAppendingString:@"#"];
            }else{
                if (completeText.length>=2 && string.length>0) {
                    NSString *secondLastChar = [completeText substringWithRange:NSMakeRange(completeText.length-2, 1)];
                    if ([secondLastChar isEqualToString:@" "]) {
                        //We have character and second last character is space and no space after space .
                        NSString *lastChar = [completeText substringFromIndex:completeText.length-1];
                        NSString *remaingChar = [completeText substringToIndex:completeText.length-1];
                        completeText = [remaingChar stringByAppendingString:@"#"];
                        completeText = [completeText stringByAppendingString:lastChar];
                    }
                    NSLog(@"secondLastChar == %@",secondLastChar);
                }
            }
        }
        
        
        
        
    }
    
    
    textField.text = completeText;
    
    
    //Updating Input Model for updated user input
    [self updateUserInput:textField];
    
    return NO;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    NSInteger returnTypeVal = textField.returnKeyType;
    BKReturnKeyType returnType = returnTypeVal;
    if (returnType == BKReturnKeyDone) {
        [textField resignFirstResponder];
    }else if(returnType == BKReturnKeyNext){
        //Return type is next we will move to next input
        
        int currentRow = (int)textField.tag;
        if (currentRow+1<arrInputKeys.count) {
            //WE have more inputs to be made as become first responder
            NSIndexPath *nextIndexPath = [NSIndexPath indexPathForRow:currentRow+1 inSection:0];
            
            UITableViewCell *cell = [tableViewForm cellForRowAtIndexPath:nextIndexPath];
            
            if (cell && [cell isKindOfClass:[InputFieldCell class]]) {
                InputFieldCell *fieldCell = (InputFieldCell *)cell;
                [fieldCell.textField becomeFirstResponder];
            }else if (cell && [cell isKindOfClass:[BioCell class]]){
                BioCell *bioCell = (BioCell *)cell;
                [bioCell.textFieldGender becomeFirstResponder];
            }
        }else{
            [textField resignFirstResponder];
        }
    }
    
    return YES;
}


#pragma mark - ScrollView Methods

-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    if (scrollView.contentOffset.y<0) {
        tableViewTopBackgroundView.hidden = NO;
        float height =topViewHeightBase*SCREEN_HEIGHT+(-1*scrollView.contentOffset.y);
        [cnsttableViewTopBackgroundViewHeight setConstant:height];
    }else{
        tableViewTopBackgroundView.hidden = YES;
        [cnsttableViewTopBackgroundViewHeight setConstant:topViewHeightBase*SCREEN_HEIGHT];
    }
}

-(BOOL)scrollViewShouldScrollToTop:(UIScrollView *)scrollView{
    return NO;
}


@end
