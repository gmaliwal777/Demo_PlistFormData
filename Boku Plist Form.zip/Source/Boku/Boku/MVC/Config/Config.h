//
//  Config.h
//  Boku
//
//  Created by Ashish Sharma on 28/07/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import <Foundation/Foundation.h>

#define IS_iPHONE_4S ([[UIScreen mainScreen] bounds].size.height == 480.f)?YES:NO

#define SCREEN_WIDTH [[UIScreen mainScreen] bounds].size.width

#define SCREEN_HEIGHT [[UIScreen mainScreen] bounds].size.height

/*
 * Make a UIColor with RGB values based on 255.
 */
#define UIColorFromRedGreenBlue(nRed,nGreen,nBlue) \
[UIColor colorWithRed:(nRed)/255.0 \
green:(nGreen)/255.0 \
blue:(nBlue)/255.0 \
alpha:1.0]

@interface Config : NSObject

@end
