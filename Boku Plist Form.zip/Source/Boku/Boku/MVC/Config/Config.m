//
//  Config.m
//  Boku
//
//  Created by Ashish Sharma on 28/07/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import "Config.h"

@implementation Config

@end
