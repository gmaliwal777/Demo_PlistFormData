//
//  Macros.h
//  TableViewFormDemo
//
//  Created by Ghanshyam on 7/28/15.
//  Copyright (c) 2015 Ghanshyam. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Macros : NSObject


/**
 *  BKKeyBoardType is defining input field keyboard type
 */
typedef enum{
    BKKeyboardTypeDefault,
    BKKeyboardTypeASCIICapable,
    BKKeyboardTypeNumbersAndPunctuation,
    BKKeyboardTypeURL,
    BKKeyboardTypeNumberPad,
    BKKeyboardTypePhonePad,
    BKKeyboardTypeNamePhonePad,
    BKKeyboardTypeEmailAddress,
    BKKeyboardTypeDecimalPad,
    BKKeyboardTypeTwitter,
    BKKeyboardTypeWebSearch,
    BKKeyboardTypeAlphabet = BKKeyboardTypeASCIICapable
}BKKeyBoardType;


/**
 *  BKReturnKeyType is defining input field keyboard type
 */
typedef enum : NSInteger {
    BKReturnKeyDefault,
    BKReturnKeyGo,
    BKReturnKeyGoogle,
    BKReturnKeyJoin,
    BKReturnKeyNext,
    BKReturnKeyRoute,
    BKReturnKeySearch,
    BKReturnKeySend,
    BKReturnKeyYahoo,
    BKReturnKeyDone,
    BKReturnKeyEmergencyCall,
} BKReturnKeyType;



/**
 *  REGISTRATION_ERROR_DOMAIN define possible sub errors
 */
typedef enum{
    REGISTRATION_INVALID_COUNTRY,
    REGISTRATION_INVALID_PHONE,
    REGISTRATION_INVALID_EMAIL,
    REGISTRATION_INVALID_PASSWORD,
    REGISTRATION_INVALID_CONFIRM_PASSWORD,
    REGISTRATION_UNKOWN_ERROR,
    REGISTRATION_INVALID_TERMS
}REGISTRATION_ERROR_DOMAIN;


/**
 *  REGISTRATION_ERROR_DOMAIN define possible sub errors
 */
typedef enum{
    PROFILE_INVALID_NAME,
    PROFILE_INVALID_BIO,
    PROFILE_INVALID_EMAIL,
    PROFILE_INVALID_LOCATION,
    PROFILE_INVALID_MOOD_STATUS,
    PROFILE_UNKOWN_HASH_TAGS
}PROFILE_ERROR_DOMAIN;


/**
 *  LOGING_ERROR_DOMAIN define possible sub errors
 */
typedef enum{
    LOGIN_INVALID_EMAIL,
    LOGIN_INVALID_PASSWORD
}LOGING_ERROR_DOMAIN;


/**
 *  LOGING_ERROR_DOMAIN define possible sub errors
 */
typedef enum{
    INVALID_OTP
}OTP_ERROR_DOMAIN;


/**
 *  BUSINESS_ACCOUNT_ERROR_DOMAIN define possible sub errors
 */
typedef enum{
    BUSINESS_ACCOUNT_INVALID_COMPANY_NAME,
    BUSINESS_ACCOUNT_INVALID_COMPANY_ADDRESS,
    BUSINESS_ACCOUNT_INVALID_PHONE_NUMBER,
    BUSINESS_ACCOUNT_INVALID_HASH_TAGS
}BUSINESS_ACCOUNT_ERROR_DOMAIN;



#define DROPDOWN_HEIGHT_MULTIPLIER          (206/320.0f)
#define ROW_HEIGHT_MULTIPLIER               (51.f/320.f)
#define HEADER_VIEW_HEIGHT_MULTIPLIER       (146.f/320.f)



#define BKFormFieldSingle @"single"
#define BKFormFieldComposite @"composite"


#define BK_INPUT_TEXT       @"Text"
#define BK_INPUT_BUTTON     @"Button"
#define BK_INPUT_LABEL      @"Label"


#define COUNTRY_LIST_STORYBOARD_ID   @"COUNTRY_LIST_STORYBOARD_ID"


#define BK_REVERSE_GEOCODE_ADDRESS_NOTIFICATION  @"BK_REVERSE_GEOCODE_ADDRESS_NOTIFICATION"

#define BK_GEOCODE_ADDRESS_NOTIFICATION         @"BK_GEOCODE_ADDRESS_NOTIFICATION"

@end
