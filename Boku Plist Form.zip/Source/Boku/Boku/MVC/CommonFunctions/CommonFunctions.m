//
//  CommonFunctions.m
//  Boku
//
//  Created by Ashish Sharma on 29/07/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import "CommonFunctions.h"
#import <objc/runtime.h>
#import "BKFormField.h"
#import "BKCompositeFormField.h"
#import "NSString+EnumParser.h"
#import <AddressBook/AddressBook.h>
#import "AlertView.h"



@implementation CommonFunctions

+(void)addBackButtonInNavigationItem:(UINavigationItem*) navigationItem
              forNavigationController:(UINavigationController*) navigationController
                           withTarget:(id) target
                          andSelector:(SEL) selector {
    
    UIButton *backButton = [[UIButton alloc] initWithFrame:CGRectMake(0.f, 0.f, 50.f, 44.f)];
    [backButton setImage:[UIImage imageNamed:@"backButton"] forState:UIControlStateNormal];
    
    if (target != nil && selector != nil) {
        [backButton addTarget:target action:selector forControlEvents:UIControlEventTouchUpInside];
    } else {
        [backButton addTarget:navigationController action:@selector(popViewControllerAnimated:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    UIBarButtonItem *barButtonBack = [[UIBarButtonItem alloc] initWithCustomView:backButton];
    
    UIBarButtonItem *negativeSpacer = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    negativeSpacer.width = -16.f;
    
    [navigationItem setLeftBarButtonItems:[NSArray arrayWithObjects:negativeSpacer,barButtonBack,nil]];
}

#pragma mark - Validation Methods

/**
 *  Used to validate email is in email format or not
 *
 *  @param email : email string to be tested for valid email
 *
 *  @return : YES if email is following email constraints or NO if email is not following email constraints
 */
+ (BOOL) validateEmail: (NSString *) email {
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    
    return [emailTest evaluateWithObject:email];
}

/**
 *  Validate BKPassword to have at least 6 alpha numerics
 *
 *  @param password : password string to be validated
 *
 *  @return : YES if password is valid or NO if email is in-valid
 */
+(BOOL)validateBKPassword:(NSString *)password{
    NSString *passwordRegex = @"^.{6,}$";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",passwordRegex];
    return [predicate evaluateWithObject:password];
}


/**
 *  Validate BKPhoneNo to have at exact 10 digit
 *
 *  @param phone : phone string to be validated
 *
 *  @return : YES if phone is valid or NO if phone is in-valid
 */
+(BOOL)validateBkPhoneNo:(NSString *)phone{
    NSString *phoneRegex = @"^[0-9]{10}$";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",phoneRegex];
    return [predicate evaluateWithObject:phone];
}

#pragma mark - Utility Methods



/**
 *  Used to remove special characters from string
 *
 *  @param string : String to be processed for special characters
 *
 *  @return : return well formated string which consist only numerics
 */
+(NSString *)removeSpecialCharectorsOtherThenNumericFromString:(NSString *)string
{
    NSString * strippedNumber = [string stringByReplacingOccurrencesOfString:@"[^0-9]" withString:@"" options:NSRegularExpressionSearch range:NSMakeRange(0, [string length])];
    return strippedNumber;
}

/**
 *  Used to check whether App is Authorized to access Address Book
 *
 *  @param completionBlock : Block which is executed in response to AddressBook authorization user prompt
 *
 *  @return :YES if Address Book is authorized / NO if Address Book is not authorized
 */
+(BOOL)isBKAuthorizedForAddressBookWithCompletionBlock:(void(^)(bool granted, CFErrorRef error))completionBlock{
    if(ABAddressBookGetAuthorizationStatus() == kABAuthorizationStatusDenied
       ||ABAddressBookGetAuthorizationStatus() == kABAuthorizationStatusRestricted
       ) {
        NSMutableArray *arrActions = [[NSMutableArray alloc] init];
        //Ok Button
        NSDictionary *dictTab = [[NSDictionary alloc] initWithObjectsAndKeys:@"OK",@"title",^{
            
        },@"action", nil];
        [arrActions addObject:dictTab];
        
        AlertView *alert = [[AlertView alloc] init];
        [alert showAlertView:@"Boku is restricted to access your contacts, please check your settings" arrActions:arrActions];
        
        return NO;
    }else if(ABAddressBookGetAuthorizationStatus() == kABAuthorizationStatusNotDetermined){
        //Access to Address book is yet not determined, this is case when Authorization needed to access Addressbook first time
        CFErrorRef *error = nil;
        ABAddressBookRef addressBook_ = ABAddressBookCreateWithOptions(NULL, error);
        
        ABAddressBookRequestAccessWithCompletion(addressBook_, completionBlock);
        return NO;
    }else{
        return YES;
    }
    
}

#pragma mark - User Default Methods

/**
 *  Used to set user default key-value pair
 *
 *  @param key   : key
 *  @param value : value
 */
+(void)setUserDefault:(NSString *)key value:(NSString *)value{
    if (key != nil && value != nil) {
        NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
        [userDefaults removeObjectForKey:key];
        [userDefaults setObject:value forKey:key];
        [userDefaults synchronize];
    }
}

/**
 *  Used to get user default key-value pair
 *
 *  @param key : key
 *
 *  @return : value
 */
+(id)getUserDefaultValue:(NSString *)key{
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    if ([userDefaults objectForKey:key]) {
        return [userDefaults objectForKey:key];
    }
    return nil;
}


#pragma mark - InputForms Methods

/**
 *  Used to say whether plist defined input is App supported ??
 *
 *  @param inputType : input type string value
 *
 *  @return : YES if input type is available , NO if input type is not available
 */
+(BOOL)isBKSupportedInput:(NSString *)inputType{
    if (![inputType isEqualToString:BK_INPUT_TEXT] &&
        ![inputType isEqualToString:BK_INPUT_BUTTON] &&
        ![inputType isEqualToString:BK_INPUT_LABEL]) {
        return NO;
    }
    return YES;
}

/**
 *  Selector used to get array of model properties
 *
 *  @param model : model whose properties to be returned in array
 *
 *  @return : returns array of properties
 */
+(NSArray *)getModelPropertiesToArray:(Class)modelClass{
    unsigned count;
    objc_property_t *properties = class_copyPropertyList(modelClass, &count);
    NSMutableArray *arrModelProperties = [[NSMutableArray alloc] init];
    
    for (int counter = 0 ;counter<count; counter++) {
        NSString *key = [NSString stringWithUTF8String:property_getName(properties[counter])];
        [arrModelProperties addObject:key];
    }
    return arrModelProperties;
}


/**
 *  Used to create BKFormField basis on provided InputType Text Info
 *
 *  @param dictInput : InputType User info
 *  @param inputKey  : Input type key
 *
 *  @return : BKFormField indicating Input type of Profvided User Info
 */
+(BKFormField *)createBKFormFieldForTextInputInfo:(NSDictionary *)dictInput WithInputKey:(NSString *)inputKey{
    
    BKFormField *inputField = [[BKFormField alloc] initWithGesture:([dictInput objectForKey:@"tap_gesture"]?YES:NO)];
    
    
    inputField.key = inputKey;
    
    inputField.inputType = BK_INPUT_TEXT;
    
    NSString *keyboardType = [dictInput objectForKey:@"keyboard_type"];
    inputField.keyboardType = [keyboardType BKKeyBoardFromString];
    
    NSString *returnType = [dictInput objectForKey:@"return_type"];
    inputField.returnType = [returnType BKReturnKeyFromString];
    
    inputField.placeHolder = [dictInput objectForKey:@"place_holder"];
    
    inputField.isSecured = [[dictInput objectForKey:@"is_secured"] boolValue];
    
    BOOL inputFieldUserInteraction = [[dictInput objectForKey:@"user_interaction"] boolValue];
    
    inputField.userInteraction = inputFieldUserInteraction;
    
    return inputField;
}


/**
 *  Used to create BKFormField basis on provided InputType Button Info
 *
 *  @param dictInput : InputType User info
 *  @param inputKey  : Input type key
 *
 *  @return : BKFormField indicating Input type of Profvided User Info
 */
+(BKFormField *)createBKFormFieldForButtonInputInfo:(NSDictionary *)dictInput WithInputKey:(NSString *)inputKey{
    BKFormField *inputField = [[BKFormField alloc] init];
    inputField.key = inputKey;
    
    inputField.inputType = BK_INPUT_BUTTON;
    
    return inputField;
}

/**
 *  Converts Resource form input data into input model
 *
 *  @param resource   : resource file which indicate form inputs
 *  @param modelClass : Class of relevant model
 *
 *  @return : array of input fields model consist either BKFormField or BKCompositeFormField
 */
+(NSArray *)convertInputsWithResource:(NSString *)resource toModelClass:(Class)modelClass{
    
    NSString *inputFormPath = [[NSBundle mainBundle] pathForResource:resource ofType:@"plist"];
    
    //If resource file is not existing locally
    NSString *message = [NSString stringWithFormat:@"%@ is not existing in your bundle",resource];
    NSAssert(inputFormPath, message);
    
    
    //Consist row inputs from resource plist
    NSArray* arrRowInputs = [NSArray arrayWithContentsOfFile:inputFormPath];
    
    
    //Array of model properties
    NSArray *arrModelProperties = [self getModelPropertiesToArray:modelClass];
    
    
    NSMutableArray *arrInputs = [[NSMutableArray alloc] init];
    
    for (NSDictionary *dictInput in arrRowInputs) {
        
        NSString *inputKey = [dictInput objectForKey:@"key"];
        
        //If model class is not having key which is in resource plist
        NSString *message = [NSString stringWithFormat:@"%@ model does not have property %@",NSStringFromClass(modelClass),inputKey];
        NSAssert([arrModelProperties containsObject:inputKey],message);
        
        
        //If input data in resource plist is not having field_type
        message = [NSString stringWithFormat:@"%@ key doesn't have field_type",inputKey];
        NSAssert([dictInput objectForKey:@"field_type"],message);
        
        
        //If input type in resource is App supported or not
        if ([[dictInput objectForKey:@"field_type"] isEqualToString:BKFormFieldSingle]) {
            message = [NSString stringWithFormat:@"%@ input type is not supported , which is defined in resource %@",[dictInput objectForKey:@"input_type"],resource];
            NSAssert([CommonFunctions isBKSupportedInput:[dictInput objectForKey:@"input_type"]],message);
        }
        
        
        
        if ([[dictInput objectForKey:@"field_type"] isEqualToString:BKFormFieldSingle]) {
            BKFormField *inputField ;
            
            if ([[dictInput objectForKey:@"input_type"] isEqualToString:BK_INPUT_TEXT]) {
                
                inputField = [self createBKFormFieldForTextInputInfo:dictInput WithInputKey:inputKey];
            }else if([[dictInput objectForKey:@"input_type"] isEqualToString:BK_INPUT_BUTTON]){
                
                inputField = [self createBKFormFieldForButtonInputInfo:dictInput WithInputKey:inputKey];
            }
            
            //Adding input in arrInputs , to have functioning later
            [arrInputs addObject:inputField];
            
        }else if ([[dictInput objectForKey:@"field_type"] isEqualToString:BKFormFieldComposite]){
            
            
            BKCompositeFormField *compositeField = [[BKCompositeFormField alloc] init];
            compositeField.key = inputKey;
            
            
            NSArray *arrCompositeFields = [dictInput objectForKey:@"content"];
            
            for (int counter = 0;counter<arrCompositeFields.count;counter++) {
                NSDictionary *dictInput  = [arrCompositeFields objectAtIndex:counter];
                
                NSString *subKey = [dictInput objectForKey:@"key"];
                
                BKFormField *field ;
                
                message = [NSString stringWithFormat:@"%@ input type is not supported , which is defined composite field in resource %@",[dictInput objectForKey:@"input_type"],resource];
                NSAssert([CommonFunctions isBKSupportedInput:[dictInput objectForKey:@"input_type"]],message);
                
                
                if ([[dictInput objectForKey:@"input_type"] isEqualToString:BK_INPUT_TEXT]) {
                    
                    field = [self createBKFormFieldForTextInputInfo:dictInput WithInputKey:subKey];
                }else if([[dictInput objectForKey:@"input_type"] isEqualToString:BK_INPUT_BUTTON]){
                    
                    field = [self createBKFormFieldForButtonInputInfo:dictInput WithInputKey:inputKey];
                }
                
                
                if (counter==0) {
                    compositeField.leftFormField = field;
                }else{
                    compositeField.rightFormField = field;
                }
            }
            
            
            //Adding input in arrInputs , to have functioning later
            [arrInputs addObject:compositeField];
        }
    }
    
    return arrInputs;
}
@end
