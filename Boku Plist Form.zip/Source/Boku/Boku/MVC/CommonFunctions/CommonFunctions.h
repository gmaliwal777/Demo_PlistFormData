//
//  CommonFunctions.h
//  Boku
//
//  Created by Ashish Sharma on 29/07/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface CommonFunctions : NSObject

+ (void)addBackButtonInNavigationItem:(UINavigationItem*) navigationItem
              forNavigationController:(UINavigationController*) navigationController
                           withTarget:(id) target
                          andSelector:(SEL) selector;

/**
 *  Converts Resource form input data into input model
 *
 *  @param resource   : resource file which indicate form inputs
 *  @param modelClass : Class of relevant model
 *
 *  @return : array of input fields model consist either BKFormField or BKCompositeFormField
 */
+(NSArray *)convertInputsWithResource:(NSString *)resource toModelClass:(Class)modelClass;



/**
 *  Used to get user default key-value pair
 *
 *  @param key : key
 *
 *  @return : value
 */
+(id)getUserDefaultValue:(NSString *)key;



/**
 *  Used to set user default key-value pair
 *
 *  @param key   : key
 *  @param value : value
 */
+(void)setUserDefault:(NSString *)key value:(NSString *)value;


/**
 *  Used to say whether plist defined input is App supported ??
 *
 *  @param inputType : input type string value
 *
 *  @return : YES if input type is available , NO if input type is not available
 */
+(BOOL)isBKSupportedInput:(NSString *)inputType;



/**
 *  Selector used to get array of model properties
 *
 *  @param model : model whose properties to be returned in array
 *
 *  @return : returns array of properties
 */
+(NSArray *)getModelPropertiesToArray:(Class)modelClass;


/**
 *  Used to validate email is in email format or not
 *
 *  @param email : email string to be tested for valid email
 *
 *  @return : YES if email is following email constraints or NO if email is not following email constraints
 */
+ (BOOL) validateEmail: (NSString *) email;


/**
 *  Validate BKPassword to have at least 6 alpha numerics
 *
 *  @param password : password string to be validated
 *
 *  @return : YES if password is valid or NO if email is in-valid
 */
+(BOOL)validateBKPassword:(NSString *)password;



/**
 *  Validate BKPhoneNo to have at exact 10 digit
 *
 *  @param phone : phone string to be validated
 *
 *  @return : YES if phone is valid or NO if phone is in-valid
 */
+(BOOL)validateBkPhoneNo:(NSString *)phone;


/**
 *  Used to check whether App is Authorized to access Address Book
 *
 *  @param completionBlock : Block which is executed in response to AddressBook authorization user prompt
 *
 *  @return :YES if Address Book is authorized / NO if Address Book is not authorized
 */
+(BOOL)isBKAuthorizedForAddressBookWithCompletionBlock:(void(^)(bool granted, CFErrorRef error))completionBlock;


/**
 *  Used to remove special characters from string
 *
 *  @param string : String to be processed for special characters
 *
 *  @return : return well formated string which consist only numerics
 */
+(NSString *)removeSpecialCharectorsOtherThenNumericFromString:(NSString *)string;



@end
