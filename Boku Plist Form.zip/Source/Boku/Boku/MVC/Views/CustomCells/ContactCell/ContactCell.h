//
//  ContactCell.h
//  Boku
//
//  Created by Ashish Sharma on 03/08/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ContactCell : UITableViewCell


/**
 *  Reference to User Profile image container
 */
@property (nonatomic,weak)  IBOutlet    UIImageView     *imageViewUserProfile;

/**
 *  Reference to User Name
 */
@property (nonatomic,weak)  IBOutlet    UILabel         *labelUserName;

/**
 *  Reference to Contact Number
 */
@property (nonatomic,weak)  IBOutlet    UILabel         *labelContactNo;

/**
 *  Reference to Profile Tick Mark
 */
@property (nonatomic,weak)  IBOutlet    UIButton        *buttonTickMark;


@end
