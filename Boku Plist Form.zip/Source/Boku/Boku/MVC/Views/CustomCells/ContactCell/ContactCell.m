//
//  ContactCell.m
//  Boku
//
//  Created by Ashish Sharma on 03/08/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import "ContactCell.h"

@implementation ContactCell

- (void)awakeFromNib {
    // Initialization code
    
    _imageViewUserProfile.layer.cornerRadius = _imageViewUserProfile.frame.size.width/2;
    _imageViewUserProfile.layer.masksToBounds = YES;
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
