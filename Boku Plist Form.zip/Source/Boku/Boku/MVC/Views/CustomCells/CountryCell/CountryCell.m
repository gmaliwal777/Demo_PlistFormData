//
//  CountryCell.m
//  Boku
//
//  Created by Ghanshyam on 7/31/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import "CountryCell.h"

@implementation CountryCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)prepareForReuse{
    self.labelCountryName.text = @"";
    
    
    self.labelISDCode.text = @"";
    
}
@end
