//
//  CountryCell.h
//  Boku
//
//  Created by Ghanshyam on 7/31/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CountryCell : UITableViewCell

/**
 *  Country Name
 */
@property (nonatomic,weak)  IBOutlet    UILabel     *labelCountryName;

/**
 *  Country ISD Code
 */
@property (nonatomic,weak)  IBOutlet    UILabel     *labelISDCode;

/**
 *  Country Selection
 */
@property (nonatomic,weak)  IBOutlet    UIImageView     *imgSelection;

@end
