//
//  InputFieldCell.m
//  Boku
//
//  Created by Ashish Sharma on 29/07/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import "InputFieldCell.h"

@implementation InputFieldCell

- (void)awakeFromNib {
    // Initialization code
    self.selectionStyle = UITableViewCellSelectionStyleNone;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)prepareForReuse{
    
    //Default Input Text Configuration
    _textField.secureTextEntry = NO;
    _textField.keyboardType = UIKeyboardTypeDefault;
    _textField.placeholder = @"";
    _textField.text = @"";
    
}

@end
