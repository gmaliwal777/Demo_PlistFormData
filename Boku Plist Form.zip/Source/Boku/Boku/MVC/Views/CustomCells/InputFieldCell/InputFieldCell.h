//
//  InputFieldCell.h
//  Boku
//
//  Created by Ashish Sharma on 29/07/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InputFieldCell : UITableViewCell

/**
 *  text field for user input
 */
@property (nonatomic, weak) IBOutlet UITextField *textField;

@end
