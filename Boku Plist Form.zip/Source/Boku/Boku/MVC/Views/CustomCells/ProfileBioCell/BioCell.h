//
//  BioCell.h
//  Boku
//
//  Created by Ghanshyam on 8/3/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BioCell : UITableViewCell

@property (nonatomic,weak)  IBOutlet    UITextField *textFieldGender;
@property (nonatomic,weak)  IBOutlet    UITextField *textFieldBirthday;

@end
