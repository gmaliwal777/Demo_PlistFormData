//
//  BioCell.m
//  Boku
//
//  Created by Ghanshyam on 8/3/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import "BioCell.h"

#define RIGHT_VIEW_PADDING_MULTIPLIER (5.f/320.f)

@implementation BioCell

- (void)awakeFromNib {
    // Initialization code
    
    UIImageView *imageViewRightView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"arrow"]];
    imageViewRightView.contentMode = UIViewContentModeBottom;
    imageViewRightView.frame = CGRectMake(0.f, 0.f, imageViewRightView.frame.size.width, imageViewRightView.frame.size.height+(SCREEN_WIDTH*RIGHT_VIEW_PADDING_MULTIPLIER));
    
    _textFieldGender.rightView = imageViewRightView;
    
    _textFieldBirthday.rightView = imageViewRightView;
    
    // Initialization code
    self.selectionStyle = UITableViewCellSelectionStyleNone;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)prepareForReuse{
    
    //Default Input Text Configuration
    _textFieldGender.secureTextEntry = NO;
    _textFieldGender.keyboardType = UIKeyboardTypeDefault;
    _textFieldGender.placeholder = @"";
    _textFieldGender.text = @"";
    
    _textFieldBirthday.secureTextEntry = NO;
    _textFieldBirthday.keyboardType = UIKeyboardTypeDefault;
    _textFieldBirthday.placeholder = @"";
    _textFieldBirthday.text = @"";
}


@end
