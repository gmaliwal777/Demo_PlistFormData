//
//  AppDelegate.h
//  Boku
//
//  Created by Ashish Sharma on 28/07/15.
//  Copyright (c) 2015 Plural Voice. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

/**
 *  Refrence to App window object
 */
@property (strong, nonatomic) UIWindow *window;

/**
 *  Reference to widow rootController (NavigationController)
 */
@property (weak, nonatomic)   UINavigationController  *navController;

@end

